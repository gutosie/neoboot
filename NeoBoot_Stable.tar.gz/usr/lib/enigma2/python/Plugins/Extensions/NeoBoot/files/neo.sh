#!/bin/sh

/bin/mount /dev/sdb1 /media/usb/  

exit 0