#!/bin/sh

umount -l /media/hdd
mkdir -p /media/hdd
mkdir -p /media/sda1
/bin/mount /dev/sda1 /media/hdd
/bin/mount /dev/sda1 /media/sda1

umount -l /media/usb
mkdir -p /media/usb
mkdir -p /media/sdb1
/bin/mount /dev/sdb1 /media/usb
/bin/mount /dev/sdb1 /media/sdb1


exit 0
