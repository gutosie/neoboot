import sys
import urllib, urllib2, re, os
from urllib import urlencode
from HTMLParser import HTMLParser
from urllib import quote
from urllib2 import Request, urlopen, URLError, HTTPError
from twisted.web.client import downloadPage, getPage
from xml.etree.cElementTree import fromstring
from xml.dom import minidom, Node

module_path = '/usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/'
temppath = '/tmp/'

list2=[]

def readnet(url):
    try:
     req = urllib2.Request(url)
     response = urllib2.urlopen(req)
     data = response.read()
     response.close()
     return data
    except:
     return None

    return None

def gethostname(url):
    from urlparse import parse_qs, urlparse
    query = urlparse(url)
    return query.hostname

def main_cats():
            cats=[]
            cats.append(("Black Hole Images",''))
            cats.append(("Custom Build Images",''))
#            cats.append(("Egami Images",''))
            cats.append(("OpenATV Images",''))
            cats.append(("OpenBH Images",''))
            cats.append(("OpenHDF Images",''))
            cats.append(("OpenDroid Images",''))
            cats.append(("OpenESI Images",''))
            cats.append(("OpenNFR Images",''))
            cats.append(("OpenPLi Images",''))
            cats.append(("OpenSPA Images",''))
#            cats.append(("OpenTen Images",''))
            cats.append(("OpenTR Images",''))
            cats.append(("Open Vision Images",''))
            cats.append(("OpenViX Images",''))
            cats.append(("Vu+ Images",''))
            cats.append(("PKTeam Images",''))
            cats.append(("PurE2 Images",''))
            cats.append(("SatDreamGr Images",''))
            cats.append(("VTi Images",''))
            for cat in cats:
             print "cat",cat
             cats.sort()
             addDir(cat[0], cat[0], 100, cat[1], '', 1)

def getteams(name,url,page):
       if name == 'OpenATV Images':
        mode=101
        teams = [('Miraclebox Images','http://images.mynonpublic.com/openatv/6.4/index.php?open=mbtwin',''),
               ('Octagon Images','http://images.mynonpublic.com/openatv/6.4/index.php?open=sf8',''),
               ('Vu+ Images','http://images.mynonpublic.com/openatv/6.4/index.php?open=vu',''),
               ('Zgemma Images','http://images.mynonpublic.com/openatv/6.4/index.php?open=zgemma','')]

       elif name == 'SatDreamGr Images':
        mode=103
        teams = [('Octagon Images', 'http://sgcpm.com/satdreamgr-images-8/octagon/',''),
#               ('Medi@link Images', 'http://sgcpm.com/satdreamgr-images-experimental/ixuss/',''),
               ('Vu+ Images', 'http://sgcpm.com/satdreamgr-images-8/vu/vu','')]

       elif name == 'OpenPLi Images':
        mode=105
        teams = [('Miraclebox Images', 'https://openpli.org/download/miraclebox/', ''),
               ('VU+ Images', 'https://openpli.org/download/vuplus/', ''),
               ('Zgemma Images', 'https://openpli.org/download/zgemma/', '')]

       elif name == 'OpenDroid Images':
        mode=107
        teams = [('Octagon Images','https://opendroid.org/7.0/Octagon/',''),
               ('VU+ Images','https://opendroid.org/7.0/Vu+/','')]

       elif name == 'OpenESI Images':
        mode=109
        teams = [('Miraclebox Images','http://www.openesi.eu/images/index.php?dir=Miraclebox/premium',''),
               ('Octagon Images','http://www.openesi.eu/images/index.php?dir=Octagon/',''),
               ('VU+ Images','http://www.openesi.eu/images/index.php?dir=Vu%2B/vu',''),
               ('Zgemma Images','http://www.openesi.eu/images/index.php?dir=Zgemma/zgemma','')]

       elif name == 'OpenViX Images':
        mode=111
        teams = [('Miraclebox Images','https://www.openvix.co.uk/index.php/downloads/miraclebox-images/premium-',''),
               ('Octagon Images','https://www.openvix.co.uk/index.php/downloads/octagon-images/',''),
               ('VU+ Images','https://www.openvix.co.uk/index.php/downloads/vu-plus-images/vu-',''),
               ('Zgemma Images','https://www.openvix.co.uk/index.php/downloads/zgemma-images/zgemma-','')]

       elif name == 'Vu+ Images':
        mode=123
        teams = [('Vu+ Images','http://code.vuplus.com/index.php?action=image&image=30&model=vu','')]

       elif name == 'VTi Images':
        mode=127
        teams = [('VU+ Images','http://read.cba.pl/images/VTi/vu','')]

       elif name == 'Black Hole Images':
        mode=129
        teams = [('VU+ Images','http://read.cba.pl/images/Black_Hole/vu','')]

       elif name == 'OpenBH Images':
        mode=131
        teams = [('VU+ Images','http://read.cba.pl/openBH/','')]

       elif name == 'PurE2 Images':
        mode=133
        teams = [('Octagon Images', 'http://pur-e2.club/OU/images/index.php?dir=6.5/octagon', ''),
               ('VU+ Images', 'http://pur-e2.club/OU/images/index.php?dir=6.5/vuplus', ''),
               ('Zgemma Images', 'http://pur-e2.club/OU/images/index.php?dir=6.5/airdigital/', '')]

       elif name == 'HDMU Images':
        mode=135
        teams = [('Atemio Images', 'http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=atemio', ''),
               ('Octagon Images', 'http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=sf', ''),
               ('VU+ Images', 'http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=vu', '')]

       elif name == 'OpenSPA Images':
        mode=145
        teams = [('Octagon Images','https://openspa.webhop.info/#Descarga%20de%20Im%C3%A1genes/Octagon/',''),
               ('Vuplus Images','https://openspa.webhop.info/#Descarga%20de%20Im%C3%A1genes/Vuplus/',''),
               ('Zgemma Images','https://openspa.webhop.info/#Descarga%20de%20Im%C3%A1genes/AirDigital/Zgemma%20','')]

       elif name == 'OpenNFR Images':
        mode=149
        teams = [('Octagon Images','http://dev.nachtfalke.biz/nfr/feeds/6.3/images/sf',''),
               ('Zgemma Images','http://dev.nachtfalke.biz/nfr/feeds/6.3/images/zgemma','')]

       elif name == 'OpenLD Images':
        mode=151
        teams = [('AirDigital Images','https://www.odisealinux.com/Zgemma.html',''),
               ('Formuler Images','https://www.odisealinux.com/Formuler.html',''),
               ('GigaBlue Images','https://www.odisealinux.com/Gigablue.html',''),
               ('VU+ Images','https://www.odisealinux.com/VuPlus.html',''),
               ('Xtrend Images','https://www.odisealinux.com/Xtrend.html','')]

       elif name == 'OpenHDF Images':
        mode=153
        teams = [('Octagon Images','http://read.cba.pl/Octagon/openHDF/sf',''),
               ('Zgemma Images','http://read.cba.pl/Airdigital/openHDF/zgemma','')]

       elif name == 'PKTeam Images':
        mode=155
        teams = [('Octagon Images','http://e2.pkteam.pl//index.php?dir=IMAGE%20OCTAGON%20SF8008/',''),
               ('VU+ Images','http://e2.pkteam.pl/index.php?dir=IMAGE%20VU%2B/',''),
               ('Zgemma Images','http://e2.pkteam.pl/index.php?dir=IMAGE%20ZGEMMA/','')]

       elif name == 'Egami Images':
        mode=161
        teams = [('Miraclebox Images','http://image.egami-image.com/index.php?open=mb',''),
               ('Octagon Images','http://image.egami-image.com/image-archive/index.php?open=sf',''),
               ('Zgemma Images','http://image.egami-image.com/index.php?open=zgemma','')]

#       elif name == 'OpenTen Images':
#        mode=157
#        teams = [('VU+ Images','http://read.cba.pl/Vu+/OpenTen/vu','')]

       elif name == 'Custom Build Images':
        mode=163
        teams = [('Foxbob Vu+ Images','http://read.cba.pl/foxbob/',''),
               ('OpenDonki Vu+ Images','http://read.cba.pl/opendonki/',''),
               ('OpenHDF Vu+ Images','http://read.cba.pl/openhdf/','')]

       elif name == 'Open Vision Images':
        mode=165
        teams = [('VU+ Images','http://read.cba.pl/openvision/','')]

       elif name == 'OpenTR Images':
        mode=167
        teams = [('VU+ Images','http://read.cba.pl/openTR/','')]

       for team in teams:
        print 'page',page
        teams.sort()
        addDir(team[0], team[1], mode, team[2], '', 1)
#####################
def trmodels(name,url,page):
    models = ['All_Models']
    for model in models:
     print 'model',model
     href = url + model
     addDir(model, href,168, '','', 1)
def extract_trimages(model,url,page):
    if 'openTR' in url:
       print 'model',model
       url='http://read.cba.pl/openTR/'
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
        if not '.zip' in href:
           continue
        if 'opentr' in url:
         href='http://read.cba.pl/openTR/' + href
        listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def tenmodels(name,url,page):
    models = ['duo2',
             'solo2',
             'solose',
             'ultimo',
             'uno',
             'zero',
             'duo4k',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4kse',
             'zero4k']
    for model in models:
     print 'model',model
     href = url + model
     addDir(model, href,158, '','', 1)
def extract_tenimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
           href='http://read.cba.pl/Vu+/OpenTen/vu' + model+'/'+href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def oplusmodels(name,url,page):
           if 'et' in url:
            models = ['8000',
             '8500',
             '9x00',
             '10000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
           if 'formuler' in url:
            models = ['1',
             '3',
             '4',
             '4turbo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
           if 'sf' in url:
            models = ['4008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
           if 'gb' in url:
            models = ['7252',
             '7325',
             '7356',
             '7358',
             '7362',
             '800solo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
           if 'vu' in url:
            models = ['zero',
             'uno',
             'solo',
             'solo2',
             'ultimo',
             'duo',
             'duo2',
             'solose',
             'solo4k',
             'zero4k',
             'uno4k',
             'uno4kse',
             'ultimo4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
           if 'h3' in url:
            models = ['h3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
           if 'hd1200' in url:
            models = ['hd1200']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,148, '','', 1)
def extract_oplusimages(model,url,page):
    if 'h3' in url:
       print 'model',model
       url='http://images.open-plus.es/?dir=' + model
    if 'hd1200' in url:
       print 'model',model
       url='http://images.open-plus.es/?dir=' + model
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    listdata=[]

    regx='''<a href="(.*?)" target="_parent" class="item _blank zip">\n\t\t\t\t\t\t\t\t\t\t\t\t(.*?)\t\t\t\t\t\t\t\t\t\t\t</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
           href='http://images.open-plus.es/'+href
           listdata.append((name,href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
########################################################################################################################
def visionmodels(name,url,page):
    models = ['All_Models']
    for model in models:
     print 'model',model
     href = url + model
     addDir(model, href,166, '','', 1)
def extract_visionimages(model,url,page):
    if 'openvision' in url:
       print 'model',model
       url='http://read.cba.pl/openvision/'
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
        if not '.zip' in href:
           continue
        if 'openvision' in url:
         href='http://read.cba.pl/openvision/' + href
        listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#########################################################################################################################
def custommodels(name,url,page):
            models = ['All models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,164, '','', 1)

def extract_customimages(model,url,page):
    if 'openhdf' in url:
       print 'model',model
       url='http://read.cba.pl/openhdf/'
    if 'foxbob' in url:
       print 'model',model
       url='http://read.cba.pl/foxbob/'
    if 'opendonki' in url:
       print 'model',model
       url='http://read.cba.pl/opendonki/'
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
        if not '.zip' in href:
           continue
        if 'openhdf' in url:
         href='http://read.cba.pl/openhdf/'+href
        if 'foxbob' in url:
         href='http://read.cba.pl/foxbob/'+href
        if 'opendonki' in url:
         href='http://read.cba.pl/opendonki/'+href
        listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def atvmodels(name,url,page):
           if 'zgemma' in url:
            models = ["zgemmah7",
				"zgemmah9s",
				"zgemmah9t",
				"zgemmah92h",
				"zgemmah92s",
                "zgemmah9combo",
                "zgemmah9twin",
				"zgemmah10"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'amiko' in url:
            models = ['amiko8900',
                "amikoalien",
                "amikomini",
                'vipert2c',
                "vipercombo",
                "vipercombohdd"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'anadol' in url:
            models = ["anadol4k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'atemio' in url:
            models = ["atemio5x00",
				"atemio6000",
				"atemio6100",
				"atemio6200",
				"atemionemesis"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'quadbox' in url:
            models = ["quadbox2400",
				"triplex",
				"ax51"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'e4' in url:
            models = ["classm",
				"axase3",
				"axase3c",
				"e4hd",
				"e4hdhybrid",
				"e4hdcombo",
				"e4hdultra"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'azbox' in url:
            models = ["azboxelite",
				"azboxpremium",
				"azboxpremium plus",
				"azboxminime",
				"azboxme",
				"azboxultra"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'beyonwiz' in url:
            models = ['beyonwizt2',
             'beyonwizt3',
             'beyonwizt4',
             'beyonwizu4']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'dinobot' in url:
            models = ['dinobot4k',
             'dinobot4kse']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'dm' in url:
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'dcube' in url:
            models = ['dcube']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'dynavision' in url:
            models = ['dynavisionsparkplus',
             'dynavisionspark',
             'dynavisionspark7162']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'fulan' in url:
            models = ['fulanspark1']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'optimuss' in url:
            models = ['optimussos1',
             'optimussos2',
             'optimussos1plus',
             'optimussos2plus',
             'optimussos3plus',
             'osnino',
             'osninoplus',
             'osmini',
             'osminiplus',
             'osmega',
             'arguspingulux',
             'arguspinguluxmini',
             'arguspinguluxplus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'enfinity' in url:
            models = ['enfinity',
             'x1plus',
             'x2plus',
             'xcombo',
             'evomini',
             't2cable',
             'novacombo',
             'novaip',
             'novatwin',
             'evoslim',
             'evoslimse',
             'evoslimt2c']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'formuler' in url:
            models = ['formuler1',
             'formuler1tc',
             'formuler3',
             'formuler3ip',
             'formuler4',
             'formuler4ip',
             'formuler4turbo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'genius' in url:
            models = ['genius',
             'geniuse3hd',
             'giavatar',
             'gis8120',
             'et7x00mini',
             'gi11000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'fulan' in url:
            models = ['fulanspark1']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'gb' in url:
            models = ['gb800solo',
             'gb800se',
             'gb800seplus',
             'gb800ue',
             'gb800ueplus',
             'gbultraue',
             'gbquad',
             'gbquadplus',
             'gbx1',
             'gbx2',
             'gbx3',
             'gbipbox',
             'gbue4k',
             'gbquad4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'spark' in url:
            models = ["sparkreloaded",
             "sparktriplex",
             "sparkone",
             "sparklx"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'xpeed' in url:
            models = ["xpeedlx",
             "xpeedlx",
             "speedlx3",
             "xpeedlxcs2",
             'xpeedlxcc']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'iqon' in url:
            models = ["iqonios100hd",
             "iqonios200hd",
             "iqonios300hd",
             "iqonios300hdv2",
             "force1",
             "force2",
             "force2se",
             "force1plus",
             "force2plus",
             "force2nano",
             "force3uhd",
             "force3uhdplus"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'mediabox' in url:
            models = ["mediabox",
             "mediabox4k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'enibox' in url:
            models = ["enibox"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'xp1000max' in url:
            models = ["xp1000max"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'ixuss' in url:
            models = ["ixussone",
             "ixusszero"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'mediaart200hd' in url:
            models = ["mediaart200hd"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'mega' in url:
            models = ["megaforce1plus",
             "megaforce2"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'mbtwin' in url:
            models = ["mbtwin",
             "mbmini",
             "mbminiplus",
             "mbultra",
             "mbmicro",
             "mbmicrov2",
             "mbtwinplus",
             "mbhybrid"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'xp1000mk' in url:
            models = ["xp1000mk"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'mutant' in url:
            models = ["mutant2400",
             "mutant1500",
             "mutant1265",
             "mutant1200",
             "mutant1100",
             "mutant500c",
             "mutant51",
             "mutant11"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'sf8' in url:
            models = ["formuler1",
             "sf208",
             "sf228",
             "sf3038",
             "sf4008",
             "sf8008"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'axodin' in url:
            models = ["axodin",
             "axodinc",
             "opticumtt",
             "odin2hybrid",
             "odinplus"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if '9900lx' in url:
            models = ["9900lx",
             "9910lx",
             "9911lx"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'lunix' in url:
            models = ["lunix",
             "lunix34k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'twinboxlcd' in url:
            models = ["twinboxlcd",
             "singleboxlcd"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'maram9' in url:
            models = ["maram9"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'evo' in url:
            models = ["evo",
             "evo3hd"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'mago' in url:
            models = ["mago"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'roxxs200hd' in url:
            models = ["roxxs200hd"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'sabsolo' in url:
            models = ["sabsolo",
             "sabtriple",
             "alphatriple"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'sezam' in url:
            models = ["sezam1000hd",
             "sezam5000hd",
             "sezammarvel"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'sogno' in url:
            models = ["sogno8800hd",
             "sognorevolution",
             "sognotriple"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'bwidowx' in url:
            models = ["bwidowx "]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'spycat' in url:
            models = ["spycat",
             "spycatmini",
             "spycatminiplus"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'tmtwin' in url:
            models = ["tmtwin",
             "tm2t",
             "tmsingle",
             "tmnano",
             "tmnano2t",
             "tmnano3t",
             "tmnano2super",
             "tmnanose",
             "tmnanosem2",
             "tmnanosecombo",
             "tmnanosem2plus",
             "tmnanom3",
             "tmtwin4k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'starsatlx' in url:
            models = ["starsatlx"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'tiviarmin' in url:
            models = ["tiviarmin",
             "tiviaraplus"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'galaxym6' in url:
            models = ["galaxym6"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'ventonhdx' in url:
            models = ["ventonhdx",
             "uniboxhde"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'vimastec' in url:
            models = ["vimastec1000",
             "vimastec1500"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'marvel1' in url:
            models = ["marvel1"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'vu' in url:
            models = ["vusolo",
             "vuduo",
             "vuuno",
             "vuultimo",
             "vusolo2",
             "vuduo2",
             "vusolose",
             "vusolose",
             "vuzero",
             "vusolo4k",
             "vuuno4k",
             "vuuno4kse",
             "vuultimo4k",
             "vuduo4k",
             "vuduo4kse",
             "vuzero4k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'worldvision' in url:
            models = ["worldvisionf1",
             "worldvisionf1plus"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'vizyonvita' in url:
            models = ["vizyonvita "]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'bre2ze' in url:
            models = ["bre2ze",
             "bre2zet2c",
             "bre2ze4k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'fusionhd' in url:
            models = ["fusionhd",
             "fusionhdse",
             "purehd",
             "purehdse",
             "revo4k",
             "galaxy4k"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
           if 'et7x00' in url:
            models = ["et4x00",
             "et5x00",
             "et6x00",
             "et6x00",
             "et7x00",
             "et7x00",
             "et7x00",
             "et9x00",
             "et9x00",
             "et9x00",
             "et9x00",
             "et8000",
             "et8500",
             "et10000 "]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,102, '','', 1)
def extract_atvimages(model,url,page):
    if 'zgemma' in url:
       print 'model',model
       url='http://images.mynonpublic.com/openatv/6.4/index.php?open=' + model
    if 'sf8' in url:
       print 'model',model
       url='http://images.mynonpublic.com/openatv/6.4/index.php?open=' + model
    if 'mbtwin' in url:
       print 'model',model
       url='http://images.mynonpublic.com/openatv/6.4/index.php?open=' + model
    if 'vu' in url:
       print 'model',model
       url='http://images.mynonpublic.com/openatv/6.4/index.php?open=' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href='(.*?)'>(.*?)</a><br/>'''
    images=re.findall(regx,data, re.M|re.I)
    print 'images',images
    for href,name in images:
        href='http://images.mynonpublic.com/openatv/6.4/'+href
        listdata.append((name.strip(),href))
    listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def spamodels(name,url,page):
           if 'AirDigital' in url:
            models = ["H7C",
				"H7S",
				"H9S",
				"H9T",
				"H9 Combo",
				"H9 Twin",
				"H9.2H",
				"H9.2S",]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Azbox' in url:
            models = ['AzboxHD',
             'AzboxME',]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Axas' in url:
            models = ['e3hd']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'DINOBOT' in url:
            models = ['DINOBOT 4K']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Edision' in url:
            models = ["OS mega",
				"OS mini",
				"OS mini plus",
				"OS nino"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Formuler' in url:
            models = ["F1",
				"F3",
				"F4",
				"F4 turbo"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Galaxy' in url:
            models = ["ET-7000 Mini"]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'GigaBlue' in url:
            models = ['800se',
             '800seplus',
             '800solo',
             '800ue',
             '800ueplus',
             'ultrase',
             'ultraue',
             'quad',
             'quadplus',
             'ue4k',
             'quad4k',
             'ipbox',
             'x1',
             'x2',
             'x3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Golden' in url:
            models = ['One-Triplex']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Mut@nt' in url:
            models = ["HD11",
				"HD1200",
				"HD1500",
				"HD500C",
                'HD51']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Octagon' in url:
            models = ['SF3038',
             'SF4008',
             'SF8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Opticum' in url:
            models = ['ax-odin']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'VisionNET' in url:
            models = ['marvel1']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Wetek' in url:
            models = ['WetekPlay']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
           if 'Vuplus' in url:
            models = ['vuzero',
             'vuuno',
             'vusolo',
             'vusolo2',
             'vuultimo',
             'vuduo',
             'vuduo2',
             'vusolose',
             'vusolo4k',
             'vuzero4k',
             'vuuno4k',
             'vuuno4kse',
             'vuduo4k',
             'vuultimo4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,146, '','', 1)
def extract_spaimages(model,url,page):
    print "image_url",url
    data=readnet('https://openspa.webhop.info/scan.php')
    if data is None:
       print "download error"
       return (False, 'Download error')
    listdata=[]#added this line
    import json
    jdata=json.loads(data)
    #print "name", jdata["items"][0]['name']
    info= jdata.get('items', {})
    teams=[]
    print "modelxx",model
    for item in info:
        modela=item['items']
        for item in modela:
            submodel=item['name']
            print "submode",submodel
            if not model.strip() in submodel:
               continue
            images=item['items']
            for image in images:
                image_name=image['name']
                image_path=image['path']
                #https://openspa.webhop.info/Descarga%20de%20Im%C3%A1genes/AZBox/AzboxHD
                image_path='https://openspa.webhop.info/'+image_path.replace(" ","%20")
                print 'image_name',image_name
                listdata.append((image_name,image_path.encode("utf-8")))
            listdata.reverse()#added - list it by newest

    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
########################################################################################################################################
def pktmodels(name,url,page):
           if 'VU' in url:
            models = ['duo2',
             'solo2',
             'solose',
             'zero',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4kse',
             'zero4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,156, '','', 1)
           if 'SF8008' in url:
            models = ['sf8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,156, '','', 1)
           if 'ZGEMMA' in url:
            models = ['h7',
             'h9combo',
             'h9s',
             'h9twin',
             'h92s']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,156, '','', 1)

def extract_pktimages(model,url,page):
    listdata=[]
###########################################################MipsVu+###########################################################
    if model=='duo2':
       name='''duo2_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/duo2_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))
    if model=='duo2':
       name='''duo2_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/duo2_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))

    if model=='solo2':
       name='''solo2_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/solo2_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))

    if model=='solose':
       name='''solose_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/solose_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))

    if model=='zero':
       name='''zero_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/zero_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))

#############################################################ARMv7#############################################################
    if model=='solo4k':
       name='''solo4k_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/solo4k_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))
    if model=='solo4k':
       name='''solo4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/solo4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))

    if model=='ultimo4k':
       name='''ultimo4k_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/ultimo4k_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))
    if model=='ultimo4k':
       name='''ultimo4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/ultimo4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))

    if model=='uno4k':
       name='''uno4k_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/uno4k_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))
    if model=='uno4k':
       name='''uno4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/uno4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))

    if model=='uno4kse':
       name='''uno4kse_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/uno4kse_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))
    if model=='uno4kse':
       name='''uno4kse_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/uno4kse_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))

    if model=='zero4k':
       name='''zero4k_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/zero4k_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))
    if model=='zero4k':
       name='''zero4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20VU%2B/HYPERION%207.1/zero4k_GIT-22995_PKT-4173_all_Kodi_18_6.zip'''
       listdata.append((name.strip(),href))
##################################################Zgemma###################################################################
    if model=='h7':
       name='''zgemmah7_GIT-22995_PKT-4165_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20ZGEMMA/HYPERION%207.1/zgemmah7_GIT-22995_PKT-4165_all.zip'''
       listdata.append((name.strip(),href))

    if model=='h9combo':
       name='''zgemmah9combo_GIT-22995_PKT-4198_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20ZGEMMA/HYPERION%207.1/zgemmah9combo_GIT-22995_PKT-4198_all.zip'''
       listdata.append((name.strip(),href))

    if model=='h9s':
       name='''zgemmah9s_GIT-22995_PKT-4198_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20ZGEMMA/HYPERION%207.1/zgemmah9s_GIT-22995_PKT-4198_all.zip'''
       listdata.append((name.strip(),href))

    if model=='h9twin':
       name='''zgemmah9twin_GIT-22995_PKT-4198_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20ZGEMMA/HYPERION%207.1/zgemmah9twin_GIT-22995_PKT-4198_all.zip'''
       listdata.append((name.strip(),href))

    if model=='h92s':
       name='''zgemmah92s_GIT-22995_PKT-4198_all.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20ZGEMMA/HYPERION%207.1/zgemmah92s_GIT-22995_PKT-4198_all.zip'''
       listdata.append((name.strip(),href))
#####################################################Octagon################################################################
    if model=='sf8008':
       name='''sf8008_GIT-22995_PKT-4198_all_mmc.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20OCTAGON%20SF8008/HYPERION%207.1/sf8008_GIT-22995_PKT-4198_all_mmc.zip'''
       listdata.append((name.strip(),href))
    if model=='sf8008':
       name='''sf8008_GIT-22995_PKT-4198_all_recovery_emmc.zip'''
       href='''http://e2.pkteam.pl/IMAGE%20OCTAGON%20SF8008/HYPERION%207.1/sf8008_GIT-22995_PKT-4198_all_recovery_emmc.zip'''
       listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def nssmodels(name,url,page):
           if 'Zgemma' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,144, '','', 1)
           if 'Amiko' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,144, '','', 1)
           if 'Dreambox' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,144, '','', 1)
           if 'EDISION' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,144, '','', 1)
           if 'HEROBOX' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,144, '','', 1)
           if 'Maxdigital' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,144, '','', 1)
def extract_nssimages(model,url,page):
    if 'Zgemma' in url:
       if model == 'All_Models':
        model = 'Nonsolosat%2010.0'
       print 'model',model
       url='http://www.nonsolosat.net/upload/index.php?dir=Zgemma%20Star/' + model
    if 'Amiko' in url:
       if model == 'All_Models':
        model = 'Nonsolosat%2010.0'
       print 'model',model
       url='http://www.nonsolosat.net/upload/index.php?dir=Amiko/' + model
    if 'Dreambox' in url:
       if model == 'All_Models':
        model = 'Nonsolosat%208.7'
       print 'model',model
       url='http://www.nonsolosat.net/upload/index.php?dir=Dreambox/' + model
    if 'EDISION' in url:
       if model == 'All_Models':
        model = 'Nonsolosat%208.9'
       print 'model',model
       url='http://www.nonsolosat.net/upload/index.php?dir=EDISION/' + model
    if 'HEROBOX' in url:
       if model == 'All_Models':
        model = 'Nonsolosat%2010.0'
       print 'model',model
       url='http://www.nonsolosat.net/upload/index.php?dir=HEROBOX-EX4-HD/' + model
    if 'Maxdigital' in url:
       if model == 'All_Models':
        model = 'Nonsolosat%208.8'
       print 'model',model
       url='http://www.nonsolosat.net/upload/index.php?dir=Maxdigital%20XP1000/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a class="autoindex_a" href="(.*?)">'''
    images=re.findall(regx,data, re.M|re.I)
    for href in images:
     try:href=href.split("file=")[1]
     except:continue
     name=href
     if 'zgemma' in url:
      href='http://www.nonsolosat.net/upload/Image-Nonsolosat/Zgemma%20Star/' + model+'/'+href
     elif 'amiko' in url:
      href='http://www.nonsolosat.net/upload/Image-Nonsolosat/Amiko/' + model+'/'+href
     elif 'dreambox' in url:
      href='http://www.nonsolosat.net/upload/Image-Nonsolosat/Dreambox/' + model+'/'+href
     elif 'edision' in url:
      href='http://www.nonsolosat.net/upload/Image-Nonsolosat/EDISION/' + model+'/'+href
     elif 'maxdigital' in url:
      href='http://www.nonsolosat.net/upload/Image-Nonsolosat/Maxdigital%20XP1000/' + model+'/'+href
     elif 'herobox' in url:
      href='http://www.nonsolosat.net/upload/Image-Nonsolosat/HEROBOX-EX4-HD/' + model+'/'+href
     listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def tsimodels(name,url,page):
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
                print 'model',model
                href = url + model
                addDir(model, href,140, '','', 1)
def extract_tsiimages(model,url,page):
    if 'tsimage' in url:
        url='http://tunisia-dreambox.info/tsimage-feed/unstable/3.0/images/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'tsimage' in url:
       regx='''<li><a href="(.*?)">(.*?)</a></li>'''
       images=re.findall(regx,data, re.M|re.I)
       for href,name in images:
           if not '.nfi' in href:
              continue
           href='http://tunisia-dreambox.info/tsimage-feed/unstable/3.0/images/' + model+'/'+href
           listdata.append((name,href))
           listdata.reverse()

    print 'listdata',listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def egamimodels(name,url,page):
           if 'mb' in url:
            models = ['micro',
             'microv2',
             'mini',
             'miniplus',
             'twin',
             'twinplus',
             'ultra']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'zgemma' in url:
            models = ['h7',
             'h9s',
             'h9t',
             'h9splus',
             'h9combo',
             'h92h',
             'h92s']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'sezam' in url:
            models = ['1000hd',
             '5000hd']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'xpeed' in url:
            models = ['lx12',
             'lx3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'atemio' in url:
            models = ['6000',
             '6100',
             '6200',
             'nemesis']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'sf' in url:
            models = ['4008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'hd' in url:
            models = ['51',
             '2400']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
           if 'venton' in url:
            models = ['ventonhdx',
             'uniboxhde']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,162, '','', 1)
def extract_egamiimages(model,url,page):
    if 'venton' in url:
       if model == 'ventonhdx':
        model = 'ventonhdx'
        url='http://image.egami-image.com/image-archive/index.php?open=' + model
       if model == 'uniboxhde':
        model = 'uniboxhde'
        url='http://image.egami-image.com/image-archive/index.php?open=' + model
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href='(.*?)'>(.*?)</a><br>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
     if not '.zip' in href:
      continue
     if 'mb' in url:
      href='http://image.egami-image.com/'+href
     elif 'zgemma' in url:
      href='http://image.egami-image.com/'+href
     elif 'sezam' in url:
      href='http://image.egami-image.com/image-archive/'+href
     elif 'xpeed' in url:
      href='http://image.egami-image.com/image-archive/'+href
     elif 'atemio' in url:
      href='http://image.egami-image.com/image-archive/'+href
     elif 'sf' in url:
      href='http://image.egami-image.com/image-archive/'+href
     elif 'hd' in url:
      href='http://image.egami-image.com/image-archive/'+href
     elif 'venton' in url:
      href='http://image.egami-image.com/image-archive/'+href
     listdata.append((name.strip(),href))
    listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def lodgemodels(name,url,page):
           if 'sat-lodge' in url:
            models = ['All_Models',]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,160, '','', 1)
def extract_lodgeimages(model,url,page):
    if 'sat-lodge' in url:
       if model == 'All_Models':
        model = 'Zgemma'
       print 'model',model
       url='http://webplus.sat-lodge.it/index.php?dir=' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a class="autoindex_a" href="(.*?)">'''
    images=re.findall(regx,data, re.M|re.I)
    for href in images:
           if not '.zip' in href:
              continue
           try:href=href.split("file=")[1]
           except:continue
           name=href
           href='http://webplus.sat-lodge.it/Zgemma/'+href
           listdata.append((name,href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
####################################################################################################################
def hdfmodels(name,url,page):
           if 'sf' in url:
            models = ['3038',
             '4008',
             '8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,154, '','', 1)
           if 'zgemma' in url:
            models = ['h7',
             'h9s',
             'h9t',
             'h9combo',
             'h9twin',
             'h92h',
             'h92s']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,154, '','', 1)

def extract_hdfimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
           if 'sf' in url:
            href='http://read.cba.pl/Octagon/openHDF/sf' + model+'/'+href
           elif 'zgemma' in url:
            href='http://read.cba.pl/Airdigital/openHDF/zgemma' + model+'/'+href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#############################################################################################################################
def nfrmodels(name,url,page):
           if 'zgemma' in url:
            models = ['h7',
             'h9s',
             'h9combo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'dinobot' in url:
            models = ['4k',
             '4kse']
            for model in models:
             print "model",model
             href = url + model+'/'
             addDir(model, href,150, '','', 1)
           if 'formuler' in url:
            models = ['1',
             '3',
             '4',
             '4turbo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'gb' in url:
            models = ['800seplus',
             '800ueplus',
             'quad4k',
             'quadplus',
             'ue4k',
             'ultraue',
             'x1',
             'x2',
             'x3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'mutant' in url:
            models = ['2400',
             '51']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'sf' in url:
            models = ['3038',
             '4008',
             '8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'ax51' in url:
            models = ['ax51',
             'triplex',
             'quadbox2400']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'bre2ze' in url:
            models = ['bre2ze']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'spycat' in url:
            models = ['spycat',
             'spycatmini',
             'spycatminiplus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'e4' in url:
            models = ['hd',
             'hdultra']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'odin2hybrid' in url:
            models = ['odin2hybrid',
             'odinplus',
             'opticumtt']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'optimuss' in url:
            models = ['os1',
             'os1plus',
             'os2',
             'os2plus',
             'os3plus',
             'osmega',
             'osmini',
             'osminiplus',
             'osnino']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,150, '','', 1)
           if 'et' in url:
            models = ['7x00']
            for model in models:
             print "model",model
             href = url + model+'/'
             addDir(model, href,150, '','', 1)
def extract_nfrimages(model,url,page):
    if 'zgemma' in url:
        url='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/zgemma' + model
    if 'sf' in url:
       url='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/sf' + model
    if 'spycat' in url:
       if model == 'spycat':
        model = 'spycat'
       url='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/' + model
    if 'odin2hybrid' in url:
       if model == 'odin2hybrid':
        model = 'odin2hybrid'
       url='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/' + model
    if 'optimuss' in url:
       if model == 'osmega':
        model = 'osmega'
       if model == 'osminiplus':
        model = 'osminiplus'
       if model == 'osmini':
        model = 'osmini'
       if model == 'osnino':
        model = 'osnino'
       if model == 'os1':
        model = 'optimussos1'
       if model == 'os1plus':
        model = 'optimussos1plus'
       if model == 'os2':
        model = 'optimussos2'
       if model == 'os2plus':
        model = 'optimussos2plus'
       if model == 'os3plus':
        model = 'optimussos3plus'
       url='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/' + model

    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

#    regx='''a href="../">Parent directory/</a></td><td>-</td><td>-</td></tr><tr><td><a href="(.*?)" title="(.*?)">'''
    regx='''<td><a href="(.*?)" title="(.*?)">.*?</a></td>'''
    images=re.findall(regx,data, re.M|re.I)
    print "images",images
    for href,name in images:
     print href
     if 'zgemma' in url:
      href='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/zgemma' + model+'/'+href
     elif 'sf' in url:
      href='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/sf' + model+'/'+href
     else:
      href='http://dev.nachtfalke.biz/nfr/feeds/6.3/images/' + model+'/'+href
     listdata.append((name.strip(),href))
    listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def psatmodels(name,url,page):
           if 'power-sat' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,142, '','', 1)
def extract_psatimages(model,url,page):
    if 'power-sat' in url:
       if model == 'All_Models':
        model = 'Immagini_OE_2.0_powersat'
       print 'model',model
       url='http://www.power-sat.org/power-plus/index.php?dir=Powersat_2.0/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a class="autoindex_a" href="(.*?)">'''
    images=re.findall(regx,data, re.M|re.I)
    for href in images:
           if not '.zip' in href:
              continue
           try:href=href.split("file=")[1]
           except:continue
           name=href
           href='http://www.power-sat.org/power-plus/Powersat_2.0/' + model+'/'+href
           listdata.append((name,href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def oldmodels(name,url,page):
           if 'Formuler' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
           elif 'Gigablue' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
           elif 'VuPlus' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
           elif 'Zgemma' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
           elif 'Octagon' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
           elif 'Xtrend' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
           elif 'Tiviar' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,152, '','', 1)
def extract_oldimages(model,url,page):
    if 'VuPlus' in url:
        url='https://www.odisealinux.com/VuPlus.html'
    if 'Formuler' in url:
        url='https://www.odisealinux.com/Formuler.html'
    if 'Gigablue' in url:
        url='https://www.odisealinux.com/Gigablue.html'
    if 'Zgemma' in url:
        url='https://www.odisealinux.com/Zgemma.html'
    if 'Xtrend' in url:
        url='https://www.odisealinux.com/Xtrend.html'

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    listdata=[]

    regx='''<a href="(.*?)">(.*?)</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def demonimodels(name,url,page):
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
                print 'model',model
                href = url + model
                addDir(model, href,138, '','', 1)
def extract_demoniimages(model,url,page):
    if 'demonisat' in url:
       if model == 'dm500hd':
        model = 'DM%20500%20HD'
       if model == 'dm800se':
        model = 'DM%20800se%20HD'
       if model == 'dm7020hd':
        model = 'DM%207020%20HD'
       if model == 'dm7020hdv2':
        model = 'DM%207020%20HDv2'
       if model == 'dm800sev2':
        model = 'DM%20800sev2%20HD'
       if model == 'dm500hdv2':
        model = 'DM%20500HDv2'
       if model == 'dm8000':
        model = 'DM%208000%20HD'
       print 'model',model
       url='http://www.demonisat.info/demonisat-e2Img-OE2.0/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href="(.*?)">(.*?)</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
        if not '.zip' in href:
           continue
        href='http://www.demonisat.info/demonisat-e2Img-OE2.0/' + model+'/'+href
        listdata.append((name.strip(),href))
    listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def hdmumodels(name,url,page):
           if 'atemio' in url:
            models = ['6000',
             '6100',
             'nemesis']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'azbox' in url:
            models = ['hd',
             'me',
             'minime']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'dm8000' in url:
            models = ['dm8000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'et' in url:
            models = ['4x00',
             '5x00',
             '6x00',
             '7x00',
             '8500',
             '9x00']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'Formuler' in url:
            models = ['F1',
             'F3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'gb' in url:
            models = ['quad',
             'quadplus',
             '800solo',
             '800ueplus',]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'sf' in url:
            models = ['108',
             '128',
             '138',
             '208',
             '228',
             '3038',
             '98',
             '4008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'vu' in url:
            models = ['duo',
             'solo2',
             'zero']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'we' in url:
            models = ['wetekplay']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'xcombo' in url:
            models = ['xcombo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'optimuss' in url:
            models = ['os1',
             'os1plus',
             'os2',
             'os2plus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
           if 'e3' in url:
            models = ['e3hd',
             'e4hd']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,136, '','', 1)
def extract_hdmuimages(model,url,page):
    if 'dm8000' in url:
        url='http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=' + model
    if 'xcombo' in url:
        url='http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=' + model
    if 'we' in url:
       if model == 'wetekplay':
        model = 'wetekplay'
        url='http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=' + model
    if 'e3' in url:
       if model == 'e3hd':
        model = 'e3hd'
       if model == 'e4hd':
        model = 'e4hd'
       url='http://www.hdmedia-universe.com/board/pages.php?pageid=1&box=' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<td class="list_files_table_file_link"><font color="#ff0000"><b>Flash Image: </b></font><a href="(.*?)">(.*?)</a></td>'''
    images=re.findall(regx,data, re.M|re.I)
    print "images",images
    for href,name in images:
        print href
        listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def pure2models(name,url,page):
    if 'airdigital' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'ax/' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'axas' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'dinobot' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'dmm' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'edision' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'fulan' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'GI' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'gigablue' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'mutant' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'octagon' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'vuplus' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'xcore' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
    if 'xtrend' in url:
      models = ['All_Models']
      for model in models:
       print "model",model
       href = url + model
       addDir(model, href,134, '','', 1)
def extract_pure2images(model,url,page):
    if 'airdigital' in url:
       if model == 'All_Models':
        model = 'airdigital'
       print 'model',model
       url='http://pur-e2.club/OU/images/index.php?dir=6.5/' + model
    if 'ax/' in url:
       if model == 'All_Models':
        model = 'ax'
       print 'model',model
       url='http://pur-e2.club/OU/images/index.php?dir=6.5/' + model
    if 'edision' in url:
       if model == 'All_Models':
        model = 'edision'
       print 'model',model
       url='http://pur-e2.club/OU/images/index.php?dir=6.5/' + model
    if 'octagon' in url:
       if model == 'All_Models':
        model = 'octagon'
       print 'model',model
       url='http://pur-e2.club/OU/images/index.php?dir=6.5/' + model
    if 'vuplus' in url:
       if model == 'All_Models':
        model = 'vuplus'
       print 'model',model
       url='http://pur-e2.club/OU/images/index.php?dir=6.5/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'dmm' in url:
     regx='''<a class="autoindex_a" href="(.*?)">'''
     images=re.findall(regx,data, re.M|re.I)
     for href in images:
        if not '.nfi' in href:
           continue
        try:href=href.split("file=")[1]
        except:continue
        name=href
        href='http://pur-e2.club/OU/images/6.5/' + model+'/'+href
        listdata.append((name.strip(),href))
     listdata.reverse()

    else:
     regx='''<a class="autoindex_a" href="(.*?)">'''
     images=re.findall(regx,data, re.M|re.I)
     for href in images:
        if not '.zip' in href:
           continue
        try:href=href.split("file=")[1]
        except:continue
        name=href
        href='http://pur-e2.club/OU/images/6.5/' + model+'/'+href
        listdata.append((name.strip(),href))
     listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def vtimodels(name,url,page):
            models = ['duo2',
             'solo2',
             'solose',
             'zero',
             'duo4k',
             'duo4kse',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4kse',
             'zero4k']
            for model in models:
              print 'model',model
              href = url + model
              addDir(model, href,128, '','', 1)
def extract_vtiimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href="(.*?)">(.*?)</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
           href='http://read.cba.pl/images/VTi/vu' + model+'/' + href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def bholemodels(name,url,page):
    models = ['duo2',
             'solo2',
             'solose',
             'ultimo',
             'uno',
             'zero',
             'duo4k',
             'duo4kse',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4kse',
             'zero4k']
    for model in models:
     print 'model',model
     href = url + model
     addDir(model, href,130, '','', 1)
def extract_bholeimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
           href='http://read.cba.pl/images/Black_Hole/vu' + model+'/'+href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def obhmodels(name,url,page):
    models = ['All_Models']
    for model in models:
     print 'model',model
     href = url + model
     addDir(model, href,132, '','', 1)
def extract_obhimages(model,url,page):
    if 'openBH' in url:
       print 'model',model
       url='http://read.cba.pl/openBH/'
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    images=re.findall('<a href="(.*?)">(.*?)</a>', data, re.M|re.I)
    for href,name in images:
        if not '.zip' in href:
           continue
        if 'openbh' in url:
         href='http://read.cba.pl/openBH/' + href
        listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def tbluemodels(name,url,page):
           if 'teamblue' in url:
            models = ['gb800solo',
             'gb800se',
             'gb800seplus',
             'gb800ue',
             'gb800ueplus',
             'gbultraue',
             'gbquad',
             'gbquadplus',
             'gbx1',
             'gbx2',
             'gbx3',
             'gbipbox',
             'gbue4k',
             'gbquad4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,126, '','', 1)
def extract_tblueimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href='(.*?)' class="button"><span class="mif-download mif-lg fg-darkCyan"></span>(.*?)</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
           if not '.zip' in href:
              continue
              continue
           href='http://images.teamblue.tech/6.1-release/'+href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def vuplusmodels(name,url,page):
            models = ['zero',
             'uno',
             'solo',
             'solo2',
             'ultimo',
             'duo',
             'duo2',
             'solose',
             'duo4k',
             'duo4kse',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4kse',
             'zero4k']
            for model in models:
              print 'model',model
              href = url + model
              addDir(model, href,124, '','', 1)
def extract_vuplusimages(model,url,page):
    if 'code.vuplus' in url:
       print 'model',model
       if model == 'duo':
        model = 'bm750'
        url='http://code.vuplus.com/index.php?action=image&image=30&model=' + model
       else:
        url='http://code.vuplus.com/index.php?action=image&image=30&model=vu' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<tr><td><a href="(.*?)" rel="external">(.*?)</a></td></tr>'''
    images=re.findall(regx,data, re.M|re.I)
    print 'images',images
    for href,name in images:
           href='http://code.vuplus.com'+href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def oozoonmodels(name,url,page):
           if 'oozoon' in url:
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
                print 'model',model
                href = url + model
                addDir(model, href,122, '','', 1)
def extract_oozoonimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'oozoon' in url:
       regx='''<td><a href="(.*?)">(.*?)</a></td>'''
       images=re.findall(regx,data, re.M|re.I)
       for href,name in images:
           if not '.nfi' in href:
              continue
           href='https://www.oozoon-download.de/opendreambox/images/' + model+'/'+href
           listdata.append((name,href))
       listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def opendmmodels(name,url,page):
           if 'dreamboxupdate' in url:
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
                print 'model',model
                href = url + model
                addDir(model, href,120, '','', 1)
def extract_opendmimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'dreamboxupdate' in url:
       regx='''<a class="nfi" href="(.*?)">(.*?)</a>'''
       images=re.findall(regx,data, re.M|re.I)
       for href,name in images:
           if not '.nfi' in href:
              continue
           href='http://www.dreamboxupdate.com/opendreambox/2.0.0/images/' + model+'/'+href
           listdata.append((name,href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def newnigma2models(name,url,page):
           if 'newnigma2' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,118, '','', 1)
def extract_newnigma2images(model,url,page):
    if 'newnigma2' in url:
       if model == 'All_Models':
        model = 'images'
       print 'model',model
       url='http://feed.newnigma2.to/daily/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'newnigma2' in url:
       regx='''<td><a href="(.*?)">(.*?)</a></td>'''
       images=re.findall(regx,data, re.M|re.I)
       for href,name in images:
           if not '.nfi' in href:
              continue
           href='http://feed.newnigma2.to/daily/' + model+'/'+href
           listdata.append((name,href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def merlin3models(name,url,page):
           if 'merlin3' in url:
            models = ['All_Models']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,116, '','', 1)
def extract_merlin3images(model,url,page):
    if 'merlin3' in url:
       if model == 'All_Models':
        model = 'images'
       print 'model',model
       url='http://feed.merlin3.info/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'merlin3' in url:
       regx='''<td><a href="(.*?)">(.*?)</a></td>'''
       images=re.findall(regx,data, re.M|re.I)
       for href,name in images:
           if not '.nfi' in href:
              continue
           href='http://feed.merlin3.info/' + model+'/'+href
           listdata.append((name,href))
       listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
#####################
def dreamelitemodels(name,url,page):
           if 'dream-elite' in url:
            models = ['DM500HD',
             'DM500HDv2',
             'DM800SE',
             'DM800SEv2',
             'DM7020HD',
             'DM7020HDv2',
             'DM8000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,114, '','', 1)
def extract_dreameliteimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    if 'dream-elite' in url:
       regx='''<a class="autoindex_a" href="(.*?)">'''
       images=re.findall(regx,data, re.M|re.I)
       for href in images:
           try:href=href.split("file=")[1]
           except:continue
           name=href
           href='http://images.dream-elite.net/DE4/' + model+"/"+href
           listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
######################
arm="openvix-archives"
def vixmodels(name,url,page):

           if 'edision' in url:
            models = ['os-mega',
             'os-mini',
             'os-mini-plus',
             'os-nino']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'forumler' in url:
            models = ['formuler-1',
             'formuler-f4-turbo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'gigablue' in url:
            models = ['hd800-solo-images',
             'hd800-se-images',
             'hd800-ue-images',
             'hd800-se-plus-images',
             'hd800-ue-plus-images',
             'hd-ultra-ue-images',
             'hd-x1-images',
             'hd-x3',
             'quad',
             'hd-quad-plus',
             'uhd-quad-4k',
             'uhd-ue-4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'maxdigital' in url:
            models = ['xp1000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'medialink' in url:
            models = ['ixuss-zero']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'miraclebox' in url:
            models = ['mini',
             'mini-plus',
             'mini-hybrid',
             'twin',
             'ultra',
             'micro',
             'micro-v2',
             'twin-plus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'mutant' in url:
            models = ['hd11',
             'hd500c',
             'hd1200',
             'hd1500',
             'hd2400',
             'hd51']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'octagon' in url:
            models = ['sf4008',
             'sf8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'odin' in url:
            models = ['odin-m9']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'opticum' in url:
            models = ['ax-odin-dvbc-1']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'spycat' in url:
            models = ['spycat']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'technomate' in url:
            models = ['single',
             'nano-oe',
             '2t',
             'nano-2t',
             'twin-oe',
             'twin-4k',
             'nano-2-super',
             'nano-3t',
             'nano-se',
             'nano-se-combo',
             'nano-se-m2',
             'nano-se-plus',
             'nano-se-m2-plus',
             'nano-m3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'golden' in url:
            models = ['xpeed-lx3-images']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'vu-plus' in url:
            models = ['duo-2',
             'solo-se',
             'solo-2',
             'duo-4k',
             'duo-4k-se',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4k-se',
             'zero-4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'zgemma' in url:
            models = ['h7',
             'h9s',
             'h9t',
             'h9-combo',
             'h9-twin']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','', 1)
           if 'venton' in url:
            models = ['hdx',
             'hd-eco-plus',]
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,112, '','',)
def extract_viximages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<.*?href="(.*?)" download="(.*?)".*?>'''
    images=re.findall(regx,data, re.M|re.I)
    print "images",images
    for href,name in images:
     print href
     listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
######################
def esimodels(name,url,page):
           if 'amiko' in url:
            models = ['8900',
             'alien2']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'atemio' in url:
            models = ['5x00',
             '6000',
             '6100',
             '6200',
             'nemesis']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'Azbox' in url:
            models = ['Elite',
             'ME',
             'miniME',
             'Premium',
             'Premium Plus',
             'Ultra']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'Dreambox' in url:
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'Edison' in url:
            models = ['OsMega',
             'Osmini',
             'Osmini-Plus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'GigaBlue' in url:
            models = ['gb800se',
			 'gb800seplus',
			 'gb800solo',
             'gb800ueplus',
             'gbultrase',
             'gbultraue',
             'gbultraueh',
             'gbquad',
             'gbquadplus',
             'gbue4k',
             'gbquad4k',
             'gbipbox',
             'gbx1',
             'gbx3']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'Miraclebox' in url:
            models = ['minihd',
             'miniplushd']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'mut@nt' in url:
            models = ['500c',
             '1100',
             '1200',
             '2400',
             'hd51 4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'Octagon' in url:
            models = ['sf208',
             'sf228',
             'sf4008',
             'sf8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'venton' in url:
            models = ['hdx',
             'UniboxEco']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'vu' in url:
            models = ['zero',
             'uno',
             'solo',
             'solo2',
             'ultimo',
             'duo',
             'duo2',
             'solose',
             'solo4k',
             'zero4k',
             'uno4k',
             'uno4kse',
             'duo4k',
             'ultimo4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'worldvision' in url:
            models = ['f1',
             'f1plus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'Xtrend' in url:
            models =['et4x00',
                   'et5x00',
                   'et6x00',
                   'et7x00',
                   'et8000',
                   'et8500',
                   'et9x00',
                   'et10000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
           if 'zgemma' in url:
            models = ['h7',
             'h9s',
             'h9splus',
             'h9t',
             'h9combo',
             'h9twin',
             'H9.2H',
             'H9.2S']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,110, '','', 1)
def extract_esiimages(model,url,page):
    if 'vu' in url:
       url='http://www.openesi.eu/images/index.php?dir=Vu%2B/vu' + model
    if 'Azbox' in url:
       if model == 'Elite':
        model = 'Azbox%20Elite'
       if model == 'ME':
        model = 'Azbox%20ME'
       if model == 'miniME':
        model = 'Azbox%20miniME'
       if model == 'Premium':
        model = 'Azbox%20Premium'
       if model == 'Premium Plus':
        model = 'Azbox%20Premium%20Plus'
       if model == 'Ultra':
        model = 'Azbox%20Ultra'
       url='http://www.openesi.eu/images/index.php?dir=Azbox/' + model
    if 'Octagon' in url:
       url='http://www.openesi.eu/images/index.php?dir=Octagon/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a class="autoindex_a" href="(.*?)">'''
    images=re.findall(regx,data, re.M|re.I)
    for href in images:
     try:href=href.split("file=")[1]
     except:continue
     name=href
     if 'amiko' in url:
      href='http://www.openesi.eu/images/Amiko/amiko' + model+'/'+href
     if 'atemio' in url:
      href='http://www.openesi.eu/images/Atemio/atemio' + model+'/'+href
     if 'azbox' in url:
      href='http://www.openesi.eu/images/Azbox' + model+'/'+href
     if 'dreambox' in url:
      href='http://www.openesi.eu/images/Dreambox' + model+'/'+href
     if 'edision' in url:
      href='http://www.openesi.eu/images/Edision' + model+'/'+href
     if 'gigablue' in url:
      href='http://www.openesi.eu/images/GigaBlue' + model+'/'+href
     if 'miraclebox' in url:
      href='http://www.openesi.eu/images/Miraclebox/premium' + model+'/'+href
     if 'mut@nt' in url:
      href='http://www.openesi.eu/images/Mut@nt/mut@nt' + model+'/'+href
     if 'octagon' in url:
      href='http://www.openesi.eu/images/Octagon/' + model+'/'+href
     if 'venton' in url:
      href='http://www.openesi.eu/images/Venton/venton' + model+'/'+href
     if 'vu' in url:
      href='http://www.openesi.eu/images/Vu+/vu' + model + '/' + href
     if 'worldvision' in url:
      href='http://www.openesi.eu/images/Worldvision/worldvision' + model+'/'+href
     if 'xtrend' in url:
      href='http://www.openesi.eu/images/Xtrend' + model+'/'+href
     if 'zgemma' in url:
      href='http://www.openesi.eu/images/Zgemma/zgemma' + model+'/'+href
     listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
######################
def droidmodels(name,url,page):
           if 'Atemio' in url:
            models = ['5x00',
             '6000',
             '6100',
             '6200',
             'nemesis']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Vivant' in url:
            models = ['4k',
             '4kse']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Edision' in url:
            models = ['osmini',
             'osmega',
             'osnino']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'EVO' in url:
            models = ['xcombo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Formuler' in url:
            models = ['formuler1',
             'formuler3',
             'formuler4',
             'formuler4turbo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Mut' in url:
            models = ['HD2400',
             'HD1500',
             'HD1265',
             'HD1200',
             'HD1100',
             'HD500c',
             'HD51',
             'HD11']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Octagon' in url:
            models = ['sf3038',
             'sf4008',
             'sf8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'GigaBlue' in url:
            models = ['gb800seplus',
             'gb800ueplus',
             'gbultrase',
             'gbultraue',
             'gbultraueh',
             'gbquad',
             'gbquadplus',
             'gbue4k',
             'gbquad4k',
             'gbipbox',
             'gbx1',
             'gbx2',
             'gbx3',
             'gbx3h']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Vu' in url:
            models = ['duo2',
             'ultimo',
             'solo4k',
             'zero4k',
             'uno4k',
             'uno4kse',
             'duo4k',
             'ultimo4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
           if 'Zgemma' in url:
            models = ['ss',
             's2s',
             'sh1',
             'sh2',
             'hs',
             'h2s',
             'h2splus',
             'h2h',
             'h3ac',
             'h32tc',
             'h5',
             'h52s',
             'h52splus',
             'h5ac',
             'h52tc',
             'h6',
             'h7',
             'h10']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,108, '','', 1)
def extract_droidimages(model,url,page):
    if 'Vu' in url:
       url='https://opendroid.org/7.0/Vu+/vu' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href="(.*?)">(.*?)</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
     if not '.zip' in href:
      continue
     if 'zgemma' in url:
      href='http://images.opendroid.org/6.8/Zgemma/zgemma' + model+'/'+href
     elif 'mut' in url:
      href='http://images.opendroid.org/6.8/Mut@nt/' + model+'/'+href
     elif 'octagon' in url:
      href='https://opendroid.org/7.0/Octagon/' + model+'/'+href
     elif 'gigablue' in url:
      href='http://images.opendroid.org/6.8/GigaBlue/' + model+'/'+href
     elif '/vu' in url:
      href='https://opendroid.org/7.0/Vu+/vu' + model+'/'+href
     listdata.append((name.strip(),href))
    listdata.reverse()

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
######################
def plimodels(name,url,page):
           if 'amiko' in url:
            models = ['Viper Combo',
             'Viper Combo HDD',
             'Viper T2C']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'dreambox' in url:
            models = ['DM500HD',
             'DM800se',
             'DM7020HD',
             'DM8000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'edision' in url:
            models = ['OSmega',
             'OSmini',
             'OSminiplus',
             'OSnino']
#             'OSninoplus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'formuler' in url:
            models = ['F1',
             'F3',
             'F4',
			 'F4turbo']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'd/gi/' in url:
            models = ['ET11000',
             'ET7000 mini']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'goldeninterstar' in url:
            models = ['Xpeed LX class S2/C']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'maxdigital' in url:
            models = ['XP1000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'miraclebox' in url:
            models = ['Premium Micro',
             'Premium Micro v2',
             'Premium Twin Plus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'mutant' in url:
            models = ['HD11',
             'HD1100',
             'HD1200',
             'HD1265',
			 'HD1500',
			 'HD2400',
			 'HD500C',
			 'HD51',
			 'HD530C']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'sab' in url:
            models = ['Alpha Triple HD']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'spycat' in url:
            models = ['Spycat',
			'Spycat Mini',
			'Spycat Mini Plus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'vimastec' in url:
            models = ['VS 1000',
             'VS 1500']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'vuplus' in url:
            models = ['Zero',
             'Uno',
             'Solo',
             'Solo2',
             'Ultimo',
             'Duo',
             'Duo2',
             'Solo SE',
             'Solo 4K',
             'Ultimo 4K',
             'Uno 4K',
             'Duo 4K',
             'Uno 4K SE',
             'Duo 4K SE',
             'Zero 4K']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'wetek' in url:
            models = ['Play']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'xtrend' in url:
            models =['ET4x00',
                   'ET5x00',
                   'ET6x00',
                   'ET7x00',
                   'ET8000',
                   'ET8500',
                   'ET9x00',
                   'ET10000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'zgemma' in url:
            models = ['H7.AC',
			 'H7.C',
			 'H7.S',
			 'H9 Combo',
			 'H9 Twin',
			 'H9.2H',
			 'H9.2S',
			 'H9.S',
			 'H9.T',
			 'H10']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
           elif 'xsarius' in url:
            models = ['Fusion HD',
             'Fusion HD SE',
             'Galaxy 4K FBC',
			 'Pure HD',
			 'Pure HD SE',
			 'Revo 4K']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,106, '','', 1)
def extract_pliimages(model,url,page):
    if 'amiko' in url:
       if model == 'Viper Combo':
        model = 'Viper+Combo'
       if model == 'Viper Combo HDD':
        model = 'Viper+Combo+HDD'
       if model == 'Viper T2C':
        model = 'Viper+T2%26%2347%3BC'
       url='https://openpli.org/download/amiko/' + model
    if 'edision' in url:
       if model == 'OSmega':
        model = 'OS+mega'
       if model == 'OSmini':
        model = 'OS+mini'
       if model == 'OSminiplus':
        model = 'OS+mini+%2B'
       if model == 'OSnino':
        model = 'OS+nino'
#       if model == 'osninoplus':
#        model = 'OS+nino+%2B'
       url='https://openpli.org/download/edision/' + model
    if 'formuler' in url:
       if model == 'F4turbo':
        model = 'F4+Turbo'
       url='https://openpli.org/download/formuler/' + model
    if 'd/gi/' in url:
       if model == 'ET11000':
        model = 'ET-11000'
       if model == 'ET7000 mini':
        model = 'ET-7000+Mini'
       url='https://openpli.org/download/gi/' + model
    if 'goldeninterstar' in url:
       if model == 'Xpeed LX class S2/C':
        model = 'Xpeed+LX+class+S2%26%2347%3BC'
       url='https://openpli.org/download/goldeninterstar/' + model
    if 'miraclebox' in url:
       if model == 'Premium Micro':
        model = 'Premium+Micro'
       if model == 'Premium Micro v2':
        model = 'Premium+Micro+v2'
       if model == 'Premium Twin Plus':
        model = 'Premium+Twin%2B'
       url='https://openpli.org/download/miraclebox/' + model
    if 'sab' in url:
       if model == 'Alpha Triple HD':
        model = 'Alpha+Triple+HD'
       url='https://openpli.org/download/sab/' + model
    if 'spycat' in url:
       if model == 'Spycat Mini':
        model = 'Spycat+Mini'
       if model == 'Spycat Mini Plus':
        model = 'Spycat+Mini+Plus'
       url='https://openpli.org/download/spycat/' + model
    if 'vimastec' in url:
       if model == 'VS 1000':
        model = 'VS+1000'
       if model == 'VS 1500':
        model = 'VS+1500'
       url='https://openpli.org/download/vimastec/' + model
    if 'vuplus' in url:
       if model == 'Solo SE':
        model = 'Solo+SE'
       if model == 'Uno 4K':
        model = 'Uno+4K'
       if model == 'Duo 4K':
        model = 'Duo+4K'
       if model == 'Duo 4K SE':
        model = 'Duo+4K+SE'
       if model == 'Ultimo 4K':
        model = 'Ultimo+4K'
       if model == 'Uno 4K SE':
        model = 'Uno+4K+SE'
       if model == 'Zero 4K':
        model = 'Zero+4K'
       if model == 'Solo 4K':
        model = 'Solo+4K'
       print 'model',model
       url='https://openpli.org/download/vuplus/' + model
    if 'zgemma' in url:
       if model == 'Star 2S':
        model = 'Star+2S'
       if model == 'Star H1':
        model = 'Star+H1'
       if model == 'Star H2':
        model = 'Star+H2'
       if model == 'Star S':
        model = 'Star+S'
       if model == 'H9 Combo':
        model = 'H9+Combo'
       if model == 'H9 Twin':
        model = 'H9+Twin'
       url='https://openpli.org/download/zgemma/' + model
    if 'xsarius' in url:
       if model == 'Fusion HD':
        model = 'Fusion+HD'
       if model == 'Fusion HD SE':
        model = 'Fusion+HD+SE'
       if model == 'Galaxy 4K FBC':
        model = 'Galaxy+4K+FBC'
       if model == 'Pure HD':
        model = 'Pure+HD'
       if model == 'Pure HD SE':
        model = 'Pure+HD+SE'
       if model == 'Revo 4K':
        model = 'Revo+4K'
       url='https://openpli.org/download/xsarius/' + model

    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    url=url.lower()
    listdata=[]

    regx='''<a href="(.*?)">(.*?)</a>'''
    images=re.findall(regx,data, re.M|re.I)
    for href,name in images:
     if not '.zip' in href:
      continue
     listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
######################
def satdreamgrmodels(name,url,page):
           if 'dreambox' in url:
            models = ['dm500hd',
             'dm500hdv2',
             'dm800se',
             'dm800sev2',
             'dm7020hd',
             'dm7020hdv2',
             'dm8000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif 'vu' in url:
            models = ['duo2',
             'solo2',
             'solose',
             'ultimo',
             'zero',
             'duo4k',
             'solo4k',
             'ultimo4k',
             'uno4k',
             'uno4kse',
             'zero4k']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif 'gigablue' in url:
            models = ['gbquadplus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif 'et' in url:
            models = ['et4x00',
			 'et5x00',
			 'et6x00',
			 'et7x00',
			 'et8000',
			 'et9x00',
			 'et10000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif 'ixuss' in url:
            models = ['ixusszero',
			 'ixussone']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif 'octagon' in url:
            models = ['sf4008',
             'sf8008']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif 'edision' in url:
            models = ['osmega',
             'osmini',
             'osminiplus',
             'osnino',
             'osninoplus']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
           elif '/xp' in url:
            models = ['xp1000']
            for model in models:
             print "model",model
             href = url + model
             addDir(model, href,104, '','', 1)
def extract_satdreamgrimages(model,url,page):
    print "image_url",url
    data=readnet(url)
    if data is None:
       print "download error"
       return (False, 'Download error')
    listdata=[]

    regx='''<a href="(.*?)">(.*?)</a>'''
    images = re.findall(regx, data, re.M | re.I)
    for href,name in images:
     if not '.zip' in href:
      continue
     if 'dreambox' in url:
      href='http://sgcpm.com/satdreamgr-images/dreambox/' + model + "/" + href
     elif 'ixuss' in url:
      href='http://sgcpm.com/satdreamgr-images-experimental/ixuss/' + model + "/" + href
     elif 'vu' in url:
      href='http://sgcpm.com/satdreamgr-images-8/vu/vu' + model + "/" + href
     elif 'octagon' in url:
      href='http://sgcpm.com/satdreamgr-images-8/octagon/' + model + "/" + href
     elif 'edision' in url:
      href='http://sgcpm.com/satdreamgr-images-experimental/edision/' + model + "/" + href
     elif 'et' in url:
      href='http://sgcpm.com/satdreamgr-images-experimental/et/' + model + "/" + href
     elif 'gigablue' in url:
      href='http://sgcpm.com/satdreamgr-images-experimental/gigablue/' + model + "/" + href
     elif 'xp' in url:
      href='http://sgcpm.com/satdreamgr-images-experimental/xp/' + model + "/" + href
     listdata.append((name.strip(),href))

    print "listdata",listdata
    for item in listdata:
        addDir(item[0],item[1],10,'','',1,True)
    return True,listdata
######################
def addDir(name, url, mode, iconimage, desc = '', page = '',link=False):
    global list2
    if not page == '':
        u = module_path + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&desc=' + urllib.quote_plus(desc) + '&page=' + str(page)
    else:
        u = module_path + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&desc=' + urllib.quote_plus(desc) + '&page='
    if link:
        u=url
        list2.append((name,
         u,
         iconimage,
         page))
    else:
        list2.append((name,
         u,
         iconimage,
         page))
def get_params(action_param):
    param = []
    paramstring = action_param
    if paramstring is None or paramstring == '':
        paramstring = ''
    else:
        paramstring = '?' + action_param.split('?')[1]
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

    print 'input,output', paramstring, param
    return param
def process_mode(action_param=None):
    global list2
    try:
        if os.path.exists(temppath+'ImageDowanloder.log'):
            os.remove(temppath+'ImageDowanloder.log')
        list2 = []
        print "action_param",action_param
        try:params = get_params(action_param)
        except:params={}
        url = None
        name = None
        mode=None
        page = ''
        try:
            url = urllib.unquote_plus(params['url'])
        except:
            pass
        try:
            name = urllib.unquote_plus(params['name'])
        except:
            pass
        try:
            mode=int(params['mode'])
        except:
            pass
        try:
            page = str(params['pageToken'])
        except:
            page = 1
            pass
        print 'Mode: ' + str(mode)
        print 'URL: ' + str(url)
        print 'Name: ' + str(name)
        print 'page: ' + str(page)
        if type(url) == type(str()):
            url = urllib.unquote_plus(url)
        if mode==None :
            main_cats()
        elif mode==100:
            print '' + url
            getteams(name, url, page)
        elif mode==101:
            print '' + url
            atvmodels(name, url, page)
        elif mode==102:
            extract_atvimages(name,url,1)
        elif mode==103:
            print '' + url
            satdreamgrmodels(name, url, page)
        elif mode==104:
            extract_satdreamgrimages(name,url,1)
        elif mode==105:
            print '' + url
            plimodels(name, url, page)
        elif mode==106:
            extract_pliimages(name,url,1)
        elif mode==107:
            print '' + url
            droidmodels(name, url, page)
        elif mode==108:
            extract_droidimages(name,url,1)
        elif mode==109:
            print '' + url
            esimodels(name, url, page)
        elif mode==110:
            extract_esiimages(name,url,1)
        elif mode==111:
            print '' + url
            vixmodels(name, url, page)
        elif mode==112:
            extract_viximages(name,url,1)
        elif mode==113:
            print '' + url
            dreamelitemodels(name, url, page)
        elif mode==114:
            extract_dreameliteimages(name,url,1)
        elif mode==115:
            print '' + url
            merlin3models(name, url, page)
        elif mode==116:
            extract_merlin3images(name,url,1)
        elif mode==117:
            print '' + url
            newnigma2models(name, url, page)
        elif mode==118:
            extract_newnigma2images(name,url,1)
        elif mode==119:
            print '' + url
            opendmmodels(name, url, page)
        elif mode==120:
            extract_opendmimages(name,url,1)
        elif mode==121:
            print '' + url
            oozoonmodels(name, url, page)
        elif mode==122:
            extract_oozoonimages(name,url,1)
        elif mode==123:
            print '' + url
            vuplusmodels(name, url, page)
        elif mode==124:
            extract_vuplusimages(name,url,1)
        elif mode==125:
            print '' + url
            tbluemodels(name, url, page)
        elif mode==126:
            extract_tblueimages(name,url,1)
        elif mode==127:
            print '' + url
            vtimodels(name, url, page)
        elif mode==128:
            extract_vtiimages(name,url,1)
        elif mode==129:
            print '' + url
            bholemodels(name, url, page)
        elif mode==130:
            extract_bholeimages(name,url,1)
        elif mode==131:
            print '' + url
            obhmodels(name, url, page)
        elif mode==132:
            extract_obhimages(name,url,1)
        elif mode==133:
            print '' + url
            pure2models(name, url, page)
        elif mode==134:
            extract_pure2images(name,url,1)
        elif mode==135:
            print '' + url
            hdmumodels(name, url, page)
        elif mode==136:
            extract_hdmuimages(name,url,1)
        elif mode==137:
            print '' + url
            demonimodels(name, url, page)
        elif mode==138:
            extract_demoniimages(name,url,1)
        elif mode==139:
            print '' + url
            tsimodels(name, url, page)
        elif mode==140:
            extract_tsiimages(name,url,1)
        elif mode==141:
            print '' + url
            psatmodels(name, url, page)
        elif mode==142:
            extract_psatimages(name,url,1)
        elif mode==143:
            print '' + url
            nssmodels(name, url, page)
        elif mode==144:
            extract_nssimages(name,url,1)
        elif mode==145:
            print '' + url
            spamodels(name, url, page)
        elif mode==146:
            extract_spaimages(name,url,1)
        elif mode==147:
            print '' + url
            oplusmodels(name, url, page)
        elif mode==148:
            extract_oplusimages(name,url,1)
        elif mode==149:
            print '' + url
            nfrmodels(name, url, page)
        elif mode==150:
            extract_nfrimages(name,url,1)
        elif mode==151:
            print '' + url
            oldmodels(name, url, page)
        elif mode==152:
            extract_oldimages(name,url,1)
        elif mode==153:
            print '' + url
            hdfmodels(name, url, page)
        elif mode==154:
            extract_hdfimages(name,url,1)
        elif mode==155:
            print '' + url
            pktmodels(name, url, page)
        elif mode==156:
            extract_pktimages(name,url,1)
        elif mode==157:
            print '' + url
            tenmodels(name, url, page)
        elif mode==158:
            extract_tenimages(name,url,1)
        elif mode==159:
            print '' + url
            lodgemodels(name, url, page)
        elif mode==160:
            extract_lodgeimages(name,url,1)
        elif mode==161:
            print '' + url
            egamimodels(name, url, page)
        elif mode==162:
            extract_egamiimages(name,url,1)
        elif mode==163:
            print '' + url
            custommodels(name, url, page)
        elif mode==164:
            extract_customimages(name,url,1)
        elif mode==165:
            print '' + url
            visionmodels(name, url, page)
        elif mode==166:
            extract_visionimages(name,url,1)
        elif mode==167:
            print '' + url
            trmodels(name, url, page)
        elif mode==168:
            extract_trimages(name,url,1)

    except:
        addDir('', '', '', '', desc='', page='')
    print "list2",list2
    return list2
