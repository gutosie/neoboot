from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Components.ActionMap import ActionMap, NumberActionMap, HelpableActionMap
from Components.Input import Input
from Components.Sources.StaticText import StaticText
from Components.ScrollLabel import ScrollLabel
from Components.Pixmap import Pixmap
from Components.Button import Button
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.FileList import FileList
from Components.MenuList import MenuList
from Components.Sources.List import List
from Components.Slider import Slider
from Components.Harddisk import harddiskmanager
from Components.config import getConfigListEntry, ConfigSubsection, ConfigText, ConfigLocations, ConfigSelection, ConfigBoolean, ConfigYesNo
from Components.config import config
from Components.ConfigList import ConfigListScreen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.SelectionList import SelectionList
from Components.PluginComponent import plugins
from Components.AVSwitch import AVSwitch
from Tools.Directories import pathExists, fileExists, resolveFilename, SCOPE_PLUGINS, SCOPE_CURRENT_PLUGIN, SCOPE_CURRENT_SKIN, SCOPE_METADIR, SCOPE_MEDIA, SCOPE_LANGUAGE
from Tools.LoadPixmap import LoadPixmap
from enigma import  eConsoleAppContainer, ePicLoad, loadPNG, eTimer, quitMainloop, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eListbox, gFont, getDesktop
from cPickle import dump, load
from os import path as os_path, system as os_system, unlink, stat, mkdir, popen, makedirs, listdir, access, rename, remove, W_OK, R_OK, F_OK
from time import time, gmtime, strftime, localtime
from datetime import date
from Screens.Console import Console
import socket
import sys
import urllib, urllib2, re, os
from urllib import urlencode
from HTMLParser import HTMLParser
from urllib import quote
from urllib2 import Request, urlopen, URLError, HTTPError
from twisted.web.client import downloadPage, getPage
from xml.etree.cElementTree import fromstring
from xml.dom import minidom, Node
from default import process_mode
mountedDevs = []
for p in harddiskmanager.getMountedPartitions(True):
    mountedDevs.append((p.mountpoint, _(p.description) if p.description else ''))
mounted_string = 'Nothing mounted at '
config.plugins.ImageDownLoader2 = ConfigSubsection()
config.plugins.ImageDownLoader2.Downloadlocation = ConfigText(default='/media/hdd/', visible_width=50, fixed_size=False)
currversion = '2.6-r59'

DESKHEIGHT = getDesktop(0).size().height()
dwidth = getDesktop(0).size().width()
skin_path = '/usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/skin/'

def getDownloadPath():
    Downloadpath = config.plugins.ImageDownLoader2.Downloadlocation.value
    if Downloadpath.endswith('/'):
        return Downloadpath
    else:
        return Downloadpath + '/'

def freespace():
    downloadlocation = getDownloadPath()
    try:
        diskSpace = os.statvfs(downloadlocation)
        capacity = float(diskSpace.f_bsize * diskSpace.f_blocks)
        available = float(diskSpace.f_bsize * diskSpace.f_bavail)
        fspace = round(float(available / 1048576.0), 2)
        tspace = round(float(capacity / 1048576.0), 1)
        spacestr = 'Free space(' + str(fspace) + 'MB) Total space(' + str(tspace) + 'MB)'
        return fspace
    except:
        return 0

class NewsScreen(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'infoHD.xml'
        else:
            skin = skin_path + 'infoFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        info = ''
        self['text'] = ScrollLabel(info)
        self['tspace'] = Label('About & News')
        self['key_red'] = StaticText(_('Back'))
        self['actions'] = ActionMap(['SetupActions', 'DirectionActions'], {'right': self['text'].pageDown,
         'ok': self.close,
         'up': self['text'].pageUp,
         'down': self['text'].pageDown,
         'cancel': self.close,
         'left': self['text'].pageUp}, -1)
        try:
            fp = urllib.urlopen('http://read.cba.pl/Image%20Downloader/news.txt')
            count = 0
            self.labeltext = ''
            while True:
                s = fp.readline()
                count = count + 1
                self.labeltext = self.labeltext + str(s)
                if s:
                    continue
                else:
                    break
                    continue

            fp.close()
            self['text'].setText(self.labeltext)
        except:
            self['text'].setText('Unable to download...')

class UpdateScreen(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'UpdateHD.xml'
        else:
            skin = skin_path + 'UpdateFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        info = ''
        self['key_green'] = Label(_(' '))
        self['key_red'] = Label(_('Back'))
        self['text'] = ScrollLabel(info)
        self['tspace'] = Label('Updater')
        self['actions'] = ActionMap(['SetupActions', 'DirectionActions', 'ColorActions'], {'ok': self.close,
         'cancel': self.close,
         'up': self['text'].pageUp,
         'down': self['text'].pageDown,
         'left': self['text'].pageUp,
         'right': self['text'].pageDown,
         'green': self.runupdate}, -1)
        try:
            fp = urllib.urlopen('http://read.cba.pl/Image%20Downloader/version.txt')
            count = 0
            self.labeltext = ''
            s1 = fp.readline()
            s2 = fp.readline()
            s3 = fp.readline()
            s1 = s1.strip()
            s2 = s2.strip()
            s3 = s3.strip()
            self.link = s2
            self.version = s1
            self.info = s3
            fp.close()
            cstr = s1 + ' ' + s2
            if s1 <= currversion:
                self['text'].setText('\nNo updates available !')
                self.update = False
                self['key_green'].setText(' ')
            else:
                updatestr = '\nNew update ' + s1 + ' is available !  \n\nUpdates:\n' + self.info + '\n\n\n\n\n\nPress GREEN button to start updating !'
                self.update = True
                self['text'].setText(updatestr)
                self['key_green'].setText('Update')
        except:
            self['text'].setText('Unable to check for updates, no internet connection or server down, please check later !')

    def runupdate(self):
        if self.update == False:
            return
        com = self.link
        dom = 'Updating plugin to ' + self.version
        self.session.open(Console, _('downloading-installing: %s') % dom, ['opkg install --force-overwrite %s' % com])

class STBmodelsScreen(Screen):# 1. Screen

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'STBmodelsScreenHD.xml'
        else:
            skin = skin_path + 'STBmodelsScreenFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        mktmp = 'mkdir -p /tmp/ImageDownloader'
        self.container = eConsoleAppContainer()
        self.container.execute(mktmp)
        self['tspace'] = Label('Teams')
        self['key_yellow'] = StaticText(_('Info'))
        self['key_green'] = StaticText(_('Select'))
        self['key_blue'] = StaticText(_('Update'))
        self['key_red'] = StaticText(_('Exit'))
        self.PicLoad = ePicLoad()
        self['logo'] = Pixmap()
        self.Scale = AVSwitch().getFramebufferScale()
        self.list = []
        self['list'] = MenuList([], True, eListboxPythonMultiContent)
        self.addon = 'emu'
        self.icount = 0
        self.downloading = False
        self['actions'] = ActionMap(["DirectionActions",'SetupActions', 'ColorActions'], {'ok': self.okClicked,
         'yellow': self.shownews,
         'green': self.okClicked,
         'blue': self.update,
         'up': self.up,
         'down': self.down,
         'left': self.left,
         'right': self.right,
         'cancel': self.exit}, -2)
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.onLayoutFinish.append(self.ShowPicture)
        self.ListToMulticontent()

    def ShowPicture(self):
        selectedEntry = self['list'].getSelectedIndex()
        try:
         if selectedEntry == 0:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/bh.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 1:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/vu.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
#         elif selectedEntry == 2:
#          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/egami.png', '/tmp/ImageDownloader/preview.png')
#          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 2:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/vision.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 3:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/atv.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 4:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openbh.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 5:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/opendroid.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 6:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openesi.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 7:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openhdf.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 8:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/opennfr.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 9:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openpli.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 10:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openspa.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 11:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/opentr.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
#         elif selectedEntry == 11:
#          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openten.png', '/tmp/ImageDownloader/preview.png')
#          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 12:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/vix.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 13:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/pkteam.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 14:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/pure2.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 15:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/satdream.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 16:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/vti.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 17:
          urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/vu.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 18:
          urllib.urlretrieve('http://178.63.156.75/ImageDownloader/logos/openspa.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 19:
          urllib.urlretrieve('http://178.63.156.75/ImageDownloader/logos/openvix.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 20:
          urllib.urlretrieve('http://178.63.156.75/ImageDownloader/logos/pkteam.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 21:
          urllib.urlretrieve('http://178.63.156.75/ImageDownloader/logos/powersat.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         elif selectedEntry == 22:
          urllib.urlretrieve('http://178.63.156.75/ImageDownloader/logos/pure2.png', '/tmp/ImageDownloader/preview.png')
          png = '/tmp/ImageDownloader/preview.png'
         if png is not None:
            self.PicLoad.setPara([self['logo'].instance.size().width(),
             self['logo'].instance.size().height(),
             self.Scale[0],
             self.Scale[1],
             0,
             1,
             '#ff111111'])
            self.PicLoad.startDecode(png)
         return
        except:
         self.downloading = False
         return

    def DecodePicture(self, PicInfo = ''):
        if '/tmp/ImageDownloader/preview.png' is not None:
            ptr = self.PicLoad.getData()
            self['logo'].instance.setPixmap(ptr)
        return

    def up(self):
        self['list'].up()
        self.ShowPicture()

    def down(self):
        self['list'].down()
        self.ShowPicture()

    def left(self):
        self['list'].pageUp()
        self.ShowPicture()

    def right(self):
        self['list'].pageDown()
        self.ShowPicture()

    def exit(self):
        cmd = 'rm -rf /tmp/ImageDownloader'
        container = eConsoleAppContainer()
        container.execute(cmd)
        self.close()
#########
    def ListToMulticontent(self, result = None):
        res = []
        theevents = []
        self.data=process_mode(None)
        if dwidth == 1280:
         self['list'].l.setItemHeight(40)
         self['list'].l.setFont(0, gFont('Regular', 24))
         for i in range(0, len(self.data)):
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 35), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 5), size=(720, 35), font=0, flags=RT_HALIGN_LEFT, text=str(self.data[i][0]), color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        else:
         self['list'].l.setItemHeight(62)
         self['list'].l.setFont(0, gFont('Regular', 38))
         for i in range(0, len(self.data)):
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 44), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 7), size=(720, 44), font=0, flags=RT_HALIGN_LEFT, text=str(self.data[i][0]), color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        self['list'].l.setList(theevents)
        self['list'].show()

    def okClicked(self):
        cindex = self['list'].getSelectionIndex()
        param=self.data[cindex][1]
#if adding logos
#use cindex's and class BlackHoleScreen & so on...
#        if cindex == 0:
#         self.session.open(BlackHoleScreen, param)
#        elif cindex == 1:
#         self.session.open(CustomBuildScreen, param)
#        elif cindex == 2:
#         self.session.open(DemonisatScreen, param)
#        elif cindex == 3:
#         self.session.open(DreamEliteScreen, param)
#        elif cindex == 4:
#         self.session.open(EgamiScreen, param)
#        elif cindex == 5:
#         self.session.open(HdmuScreen, param)
#        else:
#         self.session.open(FeedsServersScreen, param)
        self.session.open(FeedsServersScreen, param)

    def update(self):
        self.session.open(UpdateScreen)

    def shownews(self):
        self.session.open(NewsScreen)

class BlackHoleScreen(Screen):# 2. Screen

    def __init__(self, session,param=None):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'FeedsServersScreenHD.xml'
        else:
            skin = skin_path + 'FeedsServersScreenFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['tspace'] = Label("Black Hole")
        self['key_green'] = StaticText(_('Select'))
        self['key_red'] = StaticText(_('Back'))
        self.list = []
        self['list'] = MenuList([], True, eListboxPythonMultiContent)
        self.addon = 'emu'
        self.icount = 0
        self.downloading = False
        self.param=param
        self.PicLoad = ePicLoad()
        self['logo'] = Pixmap()
        self.Scale = AVSwitch().getFramebufferScale()
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.okClicked,
         'green': self.okClicked,
         'red': self.close,
         'up': self.up,
         'down': self.down,
         'left': self.left,
         'right': self.right,
         'cancel': self.close}, -2)
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.onLayoutFinish.append(self.ShowPicture)
        self.ListToMulticontent()

    def ShowPicture(self):
        selectedEntry = self['list'].getSelectedIndex()
        if selectedEntry == 0:
         urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/vu.png', '/tmp/ImageDownloader/preview.png')
         png = '/tmp/ImageDownloader/preview.png'
        else:
         urllib.urlretrieve('http://read.cba.pl/Image%20Downloader/preview/openpli.png', '/tmp/ImageDownloader/preview.png')
         png = '/tmp/ImageDownloader/preview.png'
        if png is not None:
            self.PicLoad.setPara([self['logo'].instance.size().width(),
             self['logo'].instance.size().height(),
             self.Scale[0],
             self.Scale[1],
             0,
             1,
             '#ff111111'])
            self.PicLoad.startDecode(png)
        return

    def DecodePicture(self, PicInfo = ''):
        if '/tmp/ImageDownloader/preview.png' is not None:
            ptr = self.PicLoad.getData()
            self['logo'].instance.setPixmap(ptr)
        return

    def up(self):
        self['list'].up()
        self.ShowPicture()

    def down(self):
        self['list'].down()
        self.ShowPicture()

    def left(self):
        self['list'].pageUp()
        self.ShowPicture()

    def right(self):
        self['list'].pageDown()
        self.ShowPicture()

    def ListToMulticontent(self):
        res = []
        theevents = []
        self.data=process_mode(self.param)
        if dwidth == 1280:
         self['list'].l.setItemHeight(40)
         self['list'].l.setFont(0, gFont('Regular', 24))
         for i in range(0, len(self.data)):
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 35), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 5), size=(720, 35), font=0, flags=RT_HALIGN_LEFT, text=str(self.data[i][0]), color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        else:
         self['list'].l.setItemHeight(62)
         self['list'].l.setFont(0, gFont('Regular', 38))
         for i in range(0, len(self.data)):
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 44), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 7), size=(720, 44), font=0, flags=RT_HALIGN_LEFT, text=str(self.data[i][0]), color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        self['list'].l.setList(theevents)
        self['list'].show()

    def okClicked(self):
        cindex = self['list'].getSelectionIndex()
        param=self.data[cindex][1]
        print "param1",param
        self.session.open(ServerModels, param)

class FeedsServersScreen(Screen):# 2. Screen

    def __init__(self, session,param=None):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'FeedsServersScreenHD.xml'
        else:
            skin = skin_path + 'FeedsServersScreenFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['tspace'] = Label("Brands")
        self['key_green'] = StaticText(_('Select'))
        self['key_red'] = StaticText(_('Back'))
        self.list = []
        self['list'] = MenuList([], True, eListboxPythonMultiContent)
        self.addon = 'emu'
        self.icount = 0
        self.downloading = False
        self.param=param
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.okClicked,
         'green': self.okClicked,
         'red': self.close,
         'cancel': self.close}, -2)
        self.ListToMulticontent()

    def ListToMulticontent(self):
        res = []
        theevents = []
        self.data=process_mode(self.param)
        if dwidth == 1280:
         self['list'].l.setItemHeight(40)
         self['list'].l.setFont(0, gFont('Regular', 24))
         for i in range(0, len(self.data)):
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 35), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 5), size=(720, 35), font=0, flags=RT_HALIGN_LEFT, text=str(self.data[i][0]), color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        else:
         self['list'].l.setItemHeight(62)
         self['list'].l.setFont(0, gFont('Regular', 38))
         for i in range(0, len(self.data)):
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 44), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 7), size=(720, 44), font=0, flags=RT_HALIGN_LEFT, text=str(self.data[i][0]), color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        self['list'].l.setList(theevents)
        self['list'].show()

    def okClicked(self):
        cindex = self['list'].getSelectionIndex()
        param=self.data[cindex][1]
        print "param1",param
        self.session.open(ServerModels, param)

class ServerModels(Screen):# 3. Screen

    def __init__(self, session,param=None):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'ServerModelsHD.xml'
        else:
            skin = skin_path + 'ServerModelsFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['tspace'] = Label("Models")
        self['key_green'] = StaticText(_('Select'))
        self['key_red'] = StaticText(_('Back'))
        self.list = []
        self.param=param
        self['list'] = MenuList([], True, eListboxPythonMultiContent)
        self.downloading = False
        self.downloading = True
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.okClicked,
         'green': self.okClicked,
         'red': self.close,
         'cancel': self.close}, -2)
        self.ListToMulticontent()
        return

    def ListToMulticontent(self):
        res = []
        theevents = []
        self.data=process_mode(self.param)
        if dwidth == 1280:
         self['list'].l.setItemHeight(40)
         self['list'].l.setFont(0, gFont('Regular', 24))
         for i in range(0, len(self.data)):
            model=str(self.data[i][0])
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 30), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 5), size=(540, 30), font=0, flags=RT_HALIGN_LEFT, text=model, color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        else:
         self['list'].l.setItemHeight(62)
         self['list'].l.setFont(0, gFont('Regular', 38))
         for i in range(0, len(self.data)):
            model=str(self.data[i][0])
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 44), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(60, 7), size=(540, 44), font=0, flags=RT_HALIGN_LEFT, text=model, color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        self['list'].l.setList(theevents)
        self['list'].show()

    def okClicked(self):
        cindex = self['list'].getSelectionIndex()
        param=self.data[cindex][1]
        print "paramxx",param
        self.session.open(DownloaderImages, param)
        return

class DownloaderImages(Screen):# 4. Screen

    def __init__(self, session,param=None):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'DownloaderImagesHD.xml'
        else:
            skin = skin_path + 'DownloaderImagesFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.param = param
        self['key_green'] = StaticText(_(' '))
        self['key_red'] = StaticText(_('Back'))
        self['info'] = Label(_(' '))
        self['menu'] = MenuList([], True, eListboxPythonMultiContent)
        list = []
        self.list = list
        self.status = []
        self.slist = []
        self['actions'] = ActionMap(['SetupActions', 'MenuActions', 'ColorActions'], {'ok': self.selclicked,
         'cancel': self.close,
         'red': self.close,
         'green': self.selclicked}, -2)
        self.itempreview = False
        self.ListToMulticontent()

    def ListToMulticontent(self, result = None):
        downloadpath = getDownloadPath()
        res = []
        theevents = []
        print "self.param1",self.param
        if dwidth == 1280:
         self['menu'].l.setItemHeight(40)
         self['menu'].l.setFont(0, gFont('Regular', 24))
         self.data=process_mode(self.param)
         if len(self.data)==0:
            self['info'].setText("Failed To Get Or No Image !")
            self['key_green'] = StaticText(_(' '))
            return
         self['key_green'] = StaticText(_('Select'))
         for i in range(0, len(self.data)):
            name=str(self.data[i][0])
            url = str(self.data[i][1])
            localname=os.path.split(url)[1]
            nfiname=localname.replace(".zip","nfi",)
            if os.path.exists(downloadpath + localname) or os.path.exists(downloadpath + nfiname):
                png = '/usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/skin/nbuttons/green.png'
            else:
                png = '/usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/skin/nbuttons/yellow.png'
            res.append(MultiContentEntryText(pos=(0, 1), size=(5, 30), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryPixmapAlphaTest(pos=(5, 10), size=(30, 30), png=loadPNG(png)))
            res.append(MultiContentEntryText(pos=(40, 5), size=(730, 35), font=0, flags=RT_HALIGN_LEFT, text=name, color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        else:
         self['menu'].l.setItemHeight(62)
         self['menu'].l.setFont(0, gFont('Regular', 38))
         self.data=process_mode(self.param)
         if len(self.data)==0:
            self['info'].setText("Failed To Get Or No Image !")
            self['key_green'] = StaticText(_(' '))
            return
         self['key_green'] = StaticText(_('Select'))
         for i in range(0, len(self.data)):
            name=str(self.data[i][0])
            url = str(self.data[i][1])
            localname=os.path.split(url)[1]
            nfiname=localname.replace(".zip","nfi")
            if os.path.exists(downloadpath + localname) or os.path.exists(downloadpath + nfiname):
                png = '/usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/skin/nbuttons/green.png'
            else:
                png = '/usr/lib/enigma2/python/Plugins/Extensions/ImageDownloader/skin/nbuttons/yellow.png'
            res.append(MultiContentEntryText(pos=(0, 1), size=(5, 30), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryPixmapAlphaTest(pos=(5, 20), size=(30, 30), png=loadPNG(png)))
            res.append(MultiContentEntryText(pos=(40, 7), size=(1200, 44), font=0, flags=RT_HALIGN_LEFT, text=name, color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        self.theevents = []
        self.theevents = theevents
        self['menu'].l.setList(theevents)
        self['menu'].show()

    def selclicked(self):
        cindex = self['menu'].getSelectionIndex()
        try:
            param = self.data[cindex][1]
        except:
            return
        self.session.openWithCallback(self.ListToMulticontent, ImageDownLoader, param)

class ImageDownLoader(Screen):# 5. Screen

    def __init__(self, session,param):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'ImageDownLoaderHD.xml'
        else:
            skin = skin_path + 'ImageDownLoaderFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.param=param
        self.imageurl=param
        self.menu = 0
        self.list = []
        self.oktext = _('\nSelect To Continue !')
        self.text = ''
        if True:
            self.list.append(('Download',
             _('Start Download'),
             _('\nStarts To Download Image !') + self.oktext,
             None))
            self.list.append(('Background',
             _('Download in Background'),
             _('\nDownload in Background and Explore other Images !') + self.oktext,
             None))
            self.list.append(('Downloadlocation',
             _('Set Download Location'),
             _('\nSelect Your Download Location : HDD or USB !') + self.oktext,
             None))
            self.list.append(('Files',
             _('Explore Local Images'),
             _('\nView Downloaded Images !') + self.oktext,
             None))
        self['menu'] = List(self.list)
        self['key_red'] = StaticText(_('Back'))
        self['key_green'] = StaticText(_('Select'))
        self['status'] = StaticText('')
        self['targettext'] = StaticText(_('Selected Download Location:'))
        fname = os.path.basename(self.param)
        if 'DreamEliteImages' in fname:
            a = []
            a = fname.split('=')
            fname = a[2]
        self['downloadtext'] = StaticText(_('Selected Image To Download:\n ' + fname))
        fspace = str(freespace()) + 'MB'
        self['target'] = Label(config.plugins.ImageDownLoader2.Downloadlocation.value + '\n' + 'Free Space: ' + fspace)
        self['shortcuts'] = ActionMap(['ShortcutActions', 'ColorActions', 'WizardActions', 'InfobarEPGActions'], {'ok': self.go,
         'green': self.go,
         'back': self.cancel,
         'red': self.cancel}, -1)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onShown.append(self.setWindowTitle)
        return

    def layoutFinished(self):
        idx = 0
        self['menu'].index = idx

    def setWindowTitle(self):
        self.setTitle(_('Image Downloader 2.6'))

    def fnameexists(self):
        path = getDownloadPath()
        filename = path + os.path.basename(self.imageurl)
        if fileExists(filename):
            return True
        else:
            return False

    def callMyMsg(self, result):
        path = getDownloadPath()
        if self.checkmountDownloadPath(path) == False:
            return
        if result:
            if fileExists('/etc/init.d/flashexpander.sh'):
                self.session.open(MessageBox, _('FlashExpander is used,no Image DownLoad possible.'), MessageBox.TYPE_INFO)
                self.cancel()
            else:
                runDownload = True
                self.localfile = path + os.path.basename(self.imageurl)
                self.session.openWithCallback(self.cancel, Downloader, self.imageurl, self.localfile, path)

    def checkmountDownloadPath(self, path):
        if path is None:
            self.session.open(MessageBox, _('Nothing Entered'), MessageBox.TYPE_ERROR)
            return False
        elif freespace() < 60:
            self.session.open(MessageBox, _('Free space is less than 60MB,please choose another download location,or delete files from storage device'), MessageBox.TYPE_ERROR)
            return False
        else:
            sp = []
            sp = path.split('/')
            print sp
            if len(sp) > 1:
                if sp[1] != 'media':
                    self.session.open(MessageBox, mounted_string % path, MessageBox.TYPE_ERROR)
                    return False
            mounted = False
            self.swappable = False
            sp2 = []
            f = open('/proc/mounts', 'r')
            m = f.readline()
            while m and not mounted:
                if m.find('/%s/%s' % (sp[1], sp[2])) is not -1:
                    mounted = True
                    print m
                    sp2 = m.split(' ')
                    print sp2
                    if sp2[2].startswith('ext') or sp2[2].endswith('fat'):
                        print '[stFlash] swappable'
                        self.swappable = True
                m = f.readline()

            f.close()
            if not mounted:
                self.session.open(MessageBox, mounted_string + str(path), MessageBox.TYPE_ERROR)
                return False
            if os.path.exists(config.plugins.ImageDownLoader2.Downloadlocation.value):
                try:
                    os.chmod(config.plugins.ImageDownLoader2.Downloadlocation.value, 511)
                except:
                    pass

            return True
            return

    def go(self):
        current = self['menu'].getCurrent()
        if current:
            currentEntry = current[0]
        if self.menu == 0:
            if currentEntry == 'Download':
                if not self.fnameexists() == True:
                    runDownload = True
                    path = getDownloadPath()
                    self.localfile = path + os.path.basename(self.imageurl)
                    self.session.openWithCallback(self.cancel, Downloader, self.imageurl, self.localfile, path)
                else:
                    self.session.openWithCallback(self.callMyMsg, MessageBox, _('The File Aleady Exists, ' + 'Overwrite ?'), MessageBox.TYPE_YESNO)
            if currentEntry == 'Files':
                self.session.open(ImageDownLoaderFilesScreen)
            elif currentEntry == 'Downloadlocation':
                self.session.openWithCallback(self.Downloadlocation_choosen, ImageDownLoaderDownloadLocation)
            elif currentEntry == 'Background':#added
                if not self.fnameexists() == True:
                   path = getDownloadPath()
                   self.localfile = path + os.path.basename(self.imageurl)
                   title=os.path.basename(self.imageurl)
                   from download import startdownload
                   startdownload(self.session, 'download', self.imageurl, self.localfile, title, None, True)
                else:
                   path = getDownloadPath()
                   self.localfile = path + os.path.basename(self.imageurl)
                   title=os.path.basename(self.imageurl)
                   from download import startdownload
                   startdownload(self.session, 'download', self.imageurl, self.localfile, title, None, True)
#                   from tsdownload import startdownload
#                   self.session.openWithCallback(self.startdownload, MessageBox, _('The File Aleady Exists, ' + 'Overwrite ?'), MessageBox.TYPE_YESNO)
#                   self.session.openWithCallback(self.callMyMsg2, MessageBox, _('The File Aleady Exists, ' + 'Overwrite ?'), MessageBox.TYPE_YESNO)

    def Downloadlocation_choosen(self, option):
        self.updateTarget()
        if option is not None:
            config.plugins.ImageDownLoader2.Downloadlocation.value = str(option[1])
        config.plugins.ImageDownLoader2.Downloadlocation.save()
        config.plugins.ImageDownLoader2.save()
        config.save()
        self.createDownloadfolders()
        return

    def createDownloadfolders(self):
        self.Downloadpath = getDownloadPath()
        try:
            if os_path.exists(self.Downloadpath) == False:
                makedirs(self.Downloadpath)
        except OSError:
            self.session.openWithCallback(self.goagaintoDownloadlocation, MessageBox, _('Sorry, your Download destination is not writeable.\n\nPlease choose another one.'), MessageBox.TYPE_ERROR)

    def goagaintoDownloadlocation(self, retval):
        self.session.openWithCallback(self.Downloadlocation_choosen, ImageDownLoaderDownloadLocation)

    def updateTarget(self):
        fspace = str(freespace()) + ' MB'
        self['target'].setText(''.join(config.plugins.ImageDownLoader2.Downloadlocation.value + ' Freespace:' + fspace))

    def cancel(self, result = None):
        self.close(None)
        return

class ImageDownLoaderFilesScreen(Screen):# Screen for viewing local images

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'ImageDownLoaderFilesScreenHD.xml'
        else:
            skin = skin_path + 'ImageDownLoaderFilesScreenFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        list = []
        self['menu'] = MenuList([], True, eListboxPythonMultiContent)
        self['ButtonRedtext'] = Label(_('Back '))
        self['ButtonGreentext'] = Label(_(' '))
        folder = str(config.plugins.ImageDownLoader2.Downloadlocation.value)
        fspace = str(freespace()) + 'MB'
        self['menu'].onSelectionChanged.append(self.selectionChanged)
        self['info'] = Label(folder + '\n' + ' Free space: ' + fspace)
        if folder.endswith('/'):
            self.folder = folder
        else:
            self.folder = folder + '/'
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'green': self.delimage,
         'cancel': self.close}, -2)
        self.fillplgfolders()

    def selectionChanged(self):
        try:
            fname = self['menu'].getCurrent()
            cindex = self['menu'].getSelectionIndex()
            filename = self.nfifiles[cindex][0]
            if filename.endswith(".zip") or filename.endswith('.nfi'):
               self['ButtonGreentext'].setText('Delete')
            else:
                self['ButtonGreentext'].setText(' ')
        except:
            pass

    def delimage(self):
         fname = self['menu'].getCurrent()
         cindex = self['menu'].getSelectionIndex()
         filename = self.folder + self.nfifiles[cindex][0]
         if filename.endswith(".zip") or filename.endswith('.nfi'):
            self['ButtonGreentext'].setText('Delete')
            self.session.openWithCallback(self.removefile, MessageBox, _(filename + '\nWill Be Removed,\nAre You Sure ?'), MessageBox.TYPE_YESNO)

         else:
            self['ButtonGreentext'].setText(' ')

    def removefile(self, result):
        if result:
            try:
                fname = self['menu'].getCurrent()
                cindex = self['menu'].getSelectionIndex()
                filename = self.folder + self.nfifiles[cindex][0]
                remove(filename)
                self.fillplgfolders()
            except:
                self.session.open(MessageBox, _('Unable To Delete File !'), type=MessageBox.TYPE_ERROR, timeout=5, close_on_any_key=True)

    def fillplgfolders(self):
        try:
            self.nfifiles = []
            for x in listdir(self.folder):
                if os.path.isfile(self.folder + x):
                    if x.endswith('.nfi') or x.endswith('.zip'):
                        msize = os.path.getsize(self.folder + x)
                        localimagesize = str(round(float(msize / 1048576.0), 2))
                        self.nfifiles.append([x, localimagesize])

            self.ListToMulticontent()
        except:
         self.session.open(MessageBox, _('Unable To Show Files, Check \n' + self.folder + '\nIf Available And Mounted !'), type=MessageBox.TYPE_ERROR, timeout=5, close_on_any_key=True)

    def ListToMulticontent(self):
        res = []
        theevents = []
        self.events = []
        self.events = self.nfifiles
        if dwidth == 1280:
         self['menu'].l.setItemHeight(40)
         self['menu'].l.setFont(0, gFont('Regular', 25))
         for i in range(0, len(self.events)):
            mfile = self.events[i][0]
            msize = self.events[i][1] + ' MB'
            res.append(MultiContentEntryText(pos=(0, 5), size=(2, 35), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(10, 5), size=(650, 35), font=0, flags=RT_HALIGN_LEFT, text=mfile, color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(660, 5), size=(150, 35), font=0, flags=RT_HALIGN_LEFT, text=msize, color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []
        else:
         self['menu'].l.setItemHeight(62)
         self['menu'].l.setFont(0, gFont('Regular', 34))
         for i in range(0, len(self.events)):
            mfile = self.events[i][0]
            msize = self.events[i][1] + ' MB'
            res.append(MultiContentEntryText(pos=(0, 11), size=(2, 35), font=0, flags=RT_HALIGN_LEFT, text='', color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(40, 11), size=(1100, 44), font=0, flags=RT_HALIGN_LEFT, text=mfile, color=16776960, color_sel=16777215))
            res.append(MultiContentEntryText(pos=(1000, 11), size=(170, 35), font=0, flags=RT_HALIGN_LEFT, text=msize, color=16776960, color_sel=16777215))
            theevents.append(res)
            res = []

        self['menu'].l.setList(theevents)
        self['menu'].show()
        self.selectionChanged()

class ImageDownLoaderDownloadLocation(Screen, HelpableScreen):# Screen to set download location

    def __init__(self, session, text = '', filename = '', currDir = None, location = None, userMode = False, windowTitle = _('Choose Download location'), minFree = None, autoAdd = False, editDir = False, inhibitDirs = [], inhibitMounts = []):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'ImageDownLoaderDownloadLocationHD.xml'
        else:
            skin = skin_path + 'ImageDownLoaderDownloadLocationFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self['text'] = StaticText(_('Selected Download Place:'))
        self.text = text
        self.filename = filename
        self.minFree = minFree
        self.reallocation = location
        self.location = location and location.value[:] or []
        self.userMode = userMode
        self.autoAdd = autoAdd
        self.editDir = editDir
        self.inhibitDirs = inhibitDirs
        self.inhibitMounts = inhibitMounts
        inhibitDirs = ['/bin',
         '/boot',
         '/dev',
         '/lib',
         '/proc',
         '/sbin',
         '/sys',
         '/mnt',
         '/var',
         '/home',
         '/tmp',
         '/srv',
         '/etc',
         '/share',
         '/usr',
         '/ba',
         '/MB_Images']
        inhibitMounts = ['/mnt', '/ba', '/MB_Images']
        self['filelist'] = FileList(currDir, showDirectories=True, showFiles=False, inhibitMounts=inhibitMounts, inhibitDirs=inhibitDirs)
        self['key_green'] = StaticText(_('Save'))
        self['key_red'] = StaticText(_('Back'))
        self['target'] = Label()
        if self.userMode:
            self.usermodeOn()

        class DownloadLocationActionMap(HelpableActionMap):

            def __init__(self, parent, context, actions = {}, prio = 0):
                HelpableActionMap.__init__(self, parent, context, actions, prio)

        self['WizardActions'] = DownloadLocationActionMap(self, 'WizardActions', {'left': self.left,
         'right': self.right,
         'up': self.up,
         'down': self.down,
         'ok': (self.ok, _('Select')),
         'back': (self.cancel, _('Cancel'))}, -2)
        self['ColorActions'] = DownloadLocationActionMap(self, 'ColorActions', {'red': self.cancel,
         'green': self.select}, -2)
        self.setWindowTitle()
        self.onLayoutFinish.append(self.switchToFileListOnStart)

    def setWindowTitle(self):
        self.setTitle(_('Choose Download location'))

    def switchToFileListOnStart(self):
        if self.reallocation and self.reallocation.value:
            self.currList = 'filelist'
            currDir = self['filelist'].current_directory
            if currDir in self.location:
                self['filelist'].moveToIndex(self.location.index(currDir))
        else:
            self.switchToFileList()

    def switchToFileList(self):
        if not self.userMode:
            self.currList = 'filelist'
            self['filelist'].selectionEnabled(1)
            self.updateTarget()

    def up(self):
        self[self.currList].up()
        self.updateTarget()

    def down(self):
        self[self.currList].down()
        self.updateTarget()

    def left(self):
        self[self.currList].pageUp()
        self.updateTarget()

    def right(self):
        self[self.currList].pageDown()
        self.updateTarget()

    def ok(self):
        if self.currList == 'filelist':
            if self['filelist'].canDescent():
                self['filelist'].descent()
                self.updateTarget()

    def updateTarget(self):
        currFolder = self.getPreferredFolder()
        if currFolder is not None:
            self['target'].setText(''.join((currFolder, self.filename)))
        else:
            self['target'].setText(_('Invalid Location'))
        return

    def cancel(self):
        self.close(None)
        return

    def getPreferredFolder(self):
        if self.currList == 'filelist':
            return self['filelist'].getSelection()[0]

    def saveSelection(self, ret):
        if ret:
            ret = ''.join((self.getPreferredFolder(), self.filename))
        config.plugins.ImageDownLoader2.Downloadlocation.value = ret
        config.plugins.ImageDownLoader2.Downloadlocation.save()
        config.plugins.ImageDownLoader2.save()
        config.save()
        self.close(None)
        return

    def checkmountDownloadPath(self, path):
        if path is None:
            self.session.open(MessageBox, _('Nothing Entered !'), MessageBox.TYPE_ERROR)
            return False
        else:
            sp = []
            sp = path.split('/')
            print sp
            if len(sp) > 1:
                if sp[1] != 'media':
                    self.session.open(MessageBox, mounted_string + path, MessageBox.TYPE_ERROR)
                    return False
            mounted = False
            self.swappable = False
            sp2 = []
            f = open('/proc/mounts', 'r')
            m = f.readline()
            while m and not mounted:
                if m.find('/%s/%s' % (sp[1], sp[2])) is not -1:
                    mounted = True
                    print m
                    sp2 = m.split(' ')
                    print sp2
                    if sp2[2].startswith('ext') or sp2[2].endswith('fat'):
                        print '[stFlash] swappable'
                        self.swappable = True
                m = f.readline()

            f.close()
            if not mounted:
                self.session.open(MessageBox, mounted_string + str(path), MessageBox.TYPE_ERROR)
                return False
            if os.path.exists(config.plugins.ImageDownLoader2.Downloadlocation.value):
                try:
                    os.chmod(config.plugins.ImageDownLoader2.Downloadlocation.value, 511)
                except:
                    pass

            return True
            return

    def select(self):
        currentFolder = self.getPreferredFolder()
        foldermounted = self.checkmountDownloadPath(currentFolder)
        if foldermounted == True:
            pass
        else:
            return
        if currentFolder is not None:
            if self.minFree is not None:
                try:
                    s = os.statvfs(currentFolder)
                    if s.f_bavail * s.f_bsize / 314572800 > self.minFree:
                        return self.saveSelection(True)
                except OSError:
                    pass

                self.session.openWithCallback(self.saveSelection, MessageBox, _('There Might Not Be Enough Space On The Selected Partition.\nDo You Really Want To Continue ?'), type=MessageBox.TYPE_YESNO)
            else:
                self.saveSelection(True)
        return

class Downloader(Screen):# Download screen

    def __init__(self, session, url = None, target = None, path = None):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = skin_path + 'DownloaderHD.xml'
        else:
            skin = skin_path + 'DownloaderFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        print url
        self.url = url
        self.target = target
        self.path = path
        self.nfifile = target
        self['info'] = Label('')
        self['info2'] = Label('')
        self['progress'] = ProgressBar()
        self.aborted = False
        self['progress'].setRange((0, 100))
        self['progress'].setValue(0)
        self.onLayoutFinish.append(self.startDownload)
        self['actions'] = ActionMap(['OkCancelActions'], {'cancel': self.cancel}, -1)
        self.connection = None
        return

    def startDownload(self):
        from Tools.Downloader import downloadWithProgress
        info = ' Downloading :\n %s ' % self.url
        self['info2'].setText(info)
        self.downloader = downloadWithProgress(self.url, self.target)
        self.downloader.addProgress(self.progress)
        self.downloader.start().addCallback(self.responseCompleted).addErrback(self.responseFailed)

    def progress(self, current, total):
        p = int(100 * (float(current) / float(total)))
        self['progress'].setValue(p)
        info = _('Downloading') + ' ' + '%d of %d kBytes' % (current / 1024, total / 1024)
        info = 'Downloading ... ' + str(p) + '%'
        self['info'].setText(info)
        self.setTitle(info)
        self.last_recvbytes = current

    def responseCompleted(self, string = ''):
        if self.aborted:
            self.finish(aborted=True)
        else:
            info = 'The Image Downloaded Successfully !'
            self['info2'].setText(info)
            if self.target.endswith('.zip'):
                info = 'The Image Downloaded Successfully !'
                self.session.openWithCallback(self.close, MessageBox, _(info), type=MessageBox.TYPE_INFO, timeout=3)
            elif self.target.endswith('.tar.xz'):
                info = 'The Image Downloaded Successfully !'
                self.session.openWithCallback(self.close, MessageBox, _(info), type=MessageBox.TYPE_INFO, timeout=3)
            elif self.target.endswith('.nfi'):
                info = 'The Image Downloaded Successfully !'
                self.session.openWithCallback(self.close, MessageBox, _(info), type=MessageBox.TYPE_INFO, timeout=3)
            else:
                self.close
                return

    def responseFailed(self, failure_instance = None, error_message = ''):
        self.error_message = error_message
        if error_message == '' and failure_instance is not None:
            self.error_message = failure_instance.getErrorMessage()
        info = 'Download Failed ' + self.error_message
        self['info2'].setText(info)
        self.session.openWithCallback(self.close, MessageBox, _(info), timeout=3, close_on_any_key=True)
        return

    def cancel(self):
        if self.downloader is not None:
            info = 'You Are Going To Abort Download, Are You Sure ?'
            self.session.openWithCallback(self.abort, MessageBox, _(info), type=MessageBox.TYPE_YESNO)
        else:
            self.aborted = True
            self.close()
        return

    def abort(self, result = None):
        if result:
            self.downloader.stop
            self.aborted = True
            self.close()

    def exit(self, result = None):
        self.close()
