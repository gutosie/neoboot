from Plugins.Plugin import PluginDescriptor

def main(session, **kwargs):
    from .main import STBmodelsScreen
    session.open(STBmodelsScreen)

def startSetup(menuid):
    if menuid != 'setup':
        return []
    return [(_('Image Downloader'),
      main,
      'Image Downloader',
      50)]

def Plugins(path, **kwargs):
    global plugin_path
    plugin_path = path
    list = [PluginDescriptor(name=_('Image Downloader'), description=_('Download images from image web servers'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='logo.png', fnc=main), PluginDescriptor(name=_('Image Downloader'), description=_('Download images from image web servers'), where=PluginDescriptor.WHERE_MENU, fnc=startSetup), PluginDescriptor(name=_('Image Downloader'), description=_('Download images from image web servers'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='logo.png', fnc=main)]
    return list